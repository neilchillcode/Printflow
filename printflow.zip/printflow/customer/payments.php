
<?php
session_start();
require_once "../config/database.php";

// Allow customers only
if (
    !isset($_SESSION["customer_id"]) ||
    !isset($_SESSION["user_role"]) ||
    $_SESSION["user_role"] !== "customer"
) {
    header("Location: ../login.php");
    exit;
}

$customer_id = (int) $_SESSION["customer_id"];

// CSRF protection
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$message = "";
$message_type = "";

function peso($amount) {
    return "₱" . number_format((float)$amount, 2);
}

// Handle customer payment submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (
        !isset($_POST["csrf_token"]) ||
        !hash_equals($_SESSION["csrf_token"], $_POST["csrf_token"])
    ) {
        $message = "Invalid request. Please refresh the page.";
        $message_type = "error";

    } else {

        $order_id = filter_input(INPUT_POST, "order_id", FILTER_VALIDATE_INT);
        $amount = filter_input(INPUT_POST, "amount", FILTER_VALIDATE_FLOAT);
        $payment_method = trim($_POST["payment_method"] ?? "");
        $payment_type = trim($_POST["payment_type"] ?? "");

        $allowed_methods = ["Cash", "GCash", "Bank Transfer"];
        $allowed_types = ["Down payment", "Final payment"];

        if (
            !$order_id ||
            $amount === false ||
            $amount === null ||
            $amount <= 0 ||
            !in_array($payment_method, $allowed_methods, true) ||
            !in_array($payment_type, $allowed_types, true)
        ) {
            $message = "Please enter valid payment information.";
            $message_type = "error";

        } elseif (
            !isset($_FILES["proof_file"]) ||
            $_FILES["proof_file"]["error"] !== UPLOAD_ERR_OK
        ) {
            $message = "Please upload your payment receipt or proof.";
            $message_type = "error";

        } elseif ($_FILES["proof_file"]["size"] > 5 * 1024 * 1024) {
            $message = "The uploaded image must not exceed 5 MB.";
            $message_type = "error";

        } else {

            // Confirm order ownership and retrieve its latest accepted quotation
            $order_check = $conn->prepare("
                SELECT
                    o.order_id,
                    q.amount AS quotation_amount,
                    COALESCE((
                        SELECT SUM(p.amount_paid)
                        FROM payments p
                        WHERE p.order_id = o.order_id
                    ), 0) AS total_paid,
                    COALESCE((
                        SELECT SUM(ps.amount)
                        FROM payment_submissions ps
                        WHERE ps.order_id = o.order_id
                        AND ps.status = 'Pending Verification'
                    ), 0) AS pending_amount,
                    COALESCE((
                        SELECT SUM(p.amount_paid)
                        FROM payments p
                        WHERE p.order_id = o.order_id
                        AND p.payment_type = 'Down payment'
                    ), 0) AS down_payment_total
                FROM orders o
                INNER JOIN quotations q
                    ON q.order_id = o.order_id
                WHERE o.order_id = ?
                AND o.customer_id = ?
                AND q.status = 'Accepted'
                ORDER BY q.quotation_id DESC
                LIMIT 1
            ");

            $order_check->bind_param("ii", $order_id, $customer_id);
            $order_check->execute();
            $order = $order_check->get_result()->fetch_assoc();
            $order_check->close();

            if (!$order) {

                $message = "Order not found or quotation has not been accepted.";
                $message_type = "error";

            } else {

                $remaining_balance =
                    (float)$order["quotation_amount"] -
                    (float)$order["total_paid"] -
                    (float)$order["pending_amount"];

                if ($amount > $remaining_balance + 0.001) {

                    $message = "Your submission exceeds the available balance of " .
                        peso(max(0, $remaining_balance)) . ".";
                    $message_type = "error";

                } elseif (
                    $payment_type === "Final payment" &&
                    (float)$order["down_payment_total"] <= 0
                ) {

                    $message = "A down payment must be recorded before submitting the final payment.";
                    $message_type = "error";

                } else {

                    // Validate the uploaded image using its actual MIME type
                    $file_tmp = $_FILES["proof_file"]["tmp_name"];
                    $file_info = new finfo(FILEINFO_MIME_TYPE);
                    $mime_type = $file_info->file($file_tmp);

                    $allowed_images = [
                        "image/jpeg" => "jpg",
                        "image/png" => "png",
                        "image/webp" => "webp"
                    ];

                    if (!isset($allowed_images[$mime_type])) {

                        $message = "Only JPG, PNG, and WEBP image files are allowed.";
                        $message_type = "error";

                    } else {

                        $upload_dir = "../uploads/payment_proofs/";

                        if (!is_dir($upload_dir)) {
                            $message = "Payment proof folder is missing. Please contact the administrator.";
                            $message_type = "error";

                        } else {

                            $file_name = bin2hex(random_bytes(16)) .
                                "." . $allowed_images[$mime_type];

                            $file_path = $upload_dir . $file_name;

                            if (!move_uploaded_file($file_tmp, $file_path)) {

                                $message = "Unable to upload your payment proof. Please try again.";
                                $message_type = "error";

                            } else {

                                $relative_path = "uploads/payment_proofs/" . $file_name;

                                $insert = $conn->prepare("
                                    INSERT INTO payment_submissions (
                                        order_id,
                                        customer_id,
                                        amount,
                                        payment_method,
                                        payment_type,
                                        proof_file,
                                        status
                                    )
                                    VALUES (?, ?, ?, ?, ?, ?, 'Pending Verification')
                                ");

                                $insert->bind_param(
                                    "iidsss",
                                    $order_id,
                                    $customer_id,
                                    $amount,
                                    $payment_method,
                                    $payment_type,
                                    $relative_path
                                );

                                if ($insert->execute()) {

                                    $message = "Payment proof submitted successfully! Please wait for Staff to verify your payment.";
                                    $message_type = "success";

                                } else {

                                    unlink($file_path);

                                    $message = "Unable to submit your payment. Please try again.";
                                    $message_type = "error";
                                }

                                $insert->close();
                            }
                        }
                    }
                }
            }
        }
    }
}

// Retrieve customer's recorded payment history
$history_sql = "
    SELECT
        p.payment_id,
        p.order_id,
        p.amount_paid,
        p.payment_method,
        p.payment_type,
        p.payment_date
    FROM payments p
    INNER JOIN orders o ON p.order_id = o.order_id
    WHERE o.customer_id = ?
    ORDER BY p.payment_date DESC, p.payment_id DESC
";

$stmt = $conn->prepare($history_sql);
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$result = $stmt->get_result();

// Retrieve balances for accepted quotations
$balance_sql = "
    SELECT
        o.order_id,
        o.order_date,
        o.order_status,
        q.amount AS quotation_amount,
        COALESCE((
            SELECT SUM(p.amount_paid)
            FROM payments p
            WHERE p.order_id = o.order_id
        ), 0) AS total_paid,
        COALESCE((
            SELECT SUM(ps.amount)
            FROM payment_submissions ps
            WHERE ps.order_id = o.order_id
            AND ps.status = 'Pending Verification'
        ), 0) AS pending_amount
    FROM orders o
    INNER JOIN quotations q
        ON q.order_id = o.order_id
        AND q.status = 'Accepted'
    WHERE o.customer_id = ?
    AND q.quotation_id = (
        SELECT MAX(q2.quotation_id)
        FROM quotations q2
        WHERE q2.order_id = o.order_id
        AND q2.status = 'Accepted'
    )
    ORDER BY o.order_id DESC
";

$balance_stmt = $conn->prepare($balance_sql);
$balance_stmt->bind_param("i", $customer_id);
$balance_stmt->execute();
$balance_result = $balance_stmt->get_result();

// Retrieve available orders for the payment form
$orders_sql = "
    SELECT
        o.order_id,
        q.amount AS quotation_amount,
        COALESCE((
            SELECT SUM(p.amount_paid)
            FROM payments p
            WHERE p.order_id = o.order_id
        ), 0) AS total_paid,
        COALESCE((
            SELECT SUM(ps.amount)
            FROM payment_submissions ps
            WHERE ps.order_id = o.order_id
            AND ps.status = 'Pending Verification'
        ), 0) AS pending_amount,
        COALESCE((
            SELECT SUM(p.amount_paid)
            FROM payments p
            WHERE p.order_id = o.order_id
            AND p.payment_type = 'Down payment'
        ), 0) AS down_payment_total
    FROM orders o
    INNER JOIN quotations q
        ON q.order_id = o.order_id
        AND q.status = 'Accepted'
    WHERE o.customer_id = ?
    AND q.quotation_id = (
        SELECT MAX(q2.quotation_id)
        FROM quotations q2
        WHERE q2.order_id = o.order_id
        AND q2.status = 'Accepted'
    )
    ORDER BY o.order_id DESC
";

$orders_stmt = $conn->prepare($orders_sql);
$orders_stmt->bind_param("i", $customer_id);
$orders_stmt->execute();
$orders_result = $orders_stmt->get_result();

// Retrieve customer payment submissions
$submissions_sql = "
    SELECT
        submission_id,
        order_id,
        amount,
        payment_method,
        payment_type,
        proof_file,
        status,
        submitted_at,
        staff_note
    FROM payment_submissions
    WHERE customer_id = ?
    ORDER BY submitted_at DESC, submission_id DESC
";

$submissions_stmt = $conn->prepare($submissions_sql);
$submissions_stmt->bind_param("i", $customer_id);
$submissions_stmt->execute();
$submissions_result = $submissions_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Payments | PrintFlow Pro</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Inter', sans-serif;
        }

        a:focus, button:focus, input:focus, select:focus {
            outline: 3px solid #818cf8;
            outline-offset: 3px;
        }
    </style>
</head>

<body class="bg-slate-100 text-slate-800 min-h-screen">

<header class="bg-white border-b border-slate-200">
    <div class="max-w-7xl mx-auto px-5 py-4 flex flex-wrap items-center justify-between gap-4">

        <a href="dashboard.php" class="flex items-center gap-3">
            <div class="bg-indigo-600 text-white p-2 rounded-lg">
                <i data-lucide="printer"></i>
            </div>
            <div>
                <h1 class="text-xl font-extrabold text-slate-900">PrintFlow</h1>
                <p class="text-xs text-slate-500">Customer Portal</p>
            </div>
        </a>

        <nav class="flex flex-wrap gap-2 text-sm font-semibold" aria-label="Main navigation">

            <a href="dashboard.php" class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">Dashboard</a>
            <a href="orders.php" class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">My Orders</a>
            <a href="request_order.php" class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">Request Order</a>
            <a href="quotations.php" class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">Quotations</a>
            <a href="design_proofs.php" class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">Design Proofs</a>

            <a href="payments.php" class="bg-blue-100 border border-blue-400 text-blue-900 px-4 py-2 rounded-lg hover:bg-blue-200" aria-current="page">
                Payments
            </a>

            <a href="feedback.php" class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">Feedback</a>
            <a href="../login.php?logout=1" class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">Log Out</a>

        </nav>
    </div>
</header>

<main class="max-w-7xl mx-auto px-4 py-8">

    <div class="mb-8">
        <h2 class="text-2xl font-bold">Payments</h2>
        <p class="text-slate-600 mt-1">
            Submit payment proof and monitor your order balances.
        </p>
    </div>

    <?php if ($message !== ""): ?>
        <div class="mb-6 p-4 rounded-xl border <?= $message_type === "success" ? "bg-emerald-50 border-emerald-200 text-emerald-800" : "bg-red-50 border-red-200 text-red-800" ?>" role="status">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <!-- Submit Payment -->
    <section class="bg-white rounded-xl shadow-sm border border-slate-200 p-5 mb-8">

        <h3 class="text-lg font-bold mb-2">Submit a Payment</h3>

        <p class="text-sm text-slate-500 mb-6">
            Enter your payment details and upload a receipt or screenshot.
            Staff will verify your submission before it is added to your payment records.
        </p>

        <?php if ($orders_result->num_rows > 0): ?>

            <form method="POST" enctype="multipart/form-data" class="grid grid-cols-1 md:grid-cols-2 gap-5">

                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION["csrf_token"]) ?>">

                <div>
                    <label for="order_id" class="block font-semibold mb-2">Select Order</label>
                    <select name="order_id" id="order_id" required class="w-full border border-slate-300 rounded-xl p-3 bg-white">
                        <option value="">Choose an order</option>

                        <?php while ($order = $orders_result->fetch_assoc()): ?>
                            <?php
                                $available_balance =
                                    (float)$order["quotation_amount"] -
                                    (float)$order["total_paid"] -
                                    (float)$order["pending_amount"];
                            ?>

                            <?php if ($available_balance > 0.001): ?>
                                <option value="<?= (int)$order["order_id"] ?>">
                                    Order #<?= (int)$order["order_id"] ?>
                                    — Available: <?= peso($available_balance) ?>
                                </option>
                            <?php endif; ?>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div>
                    <label for="amount" class="block font-semibold mb-2">Amount Paid (₱)</label>
                    <input type="number" name="amount" id="amount" min="0.01" step="0.01" required placeholder="Enter amount" class="w-full border border-slate-300 rounded-xl p-3">
                </div>

                <div>
                    <label for="payment_method" class="block font-semibold mb-2">Payment Method</label>
                    <select name="payment_method" id="payment_method" required class="w-full border border-slate-300 rounded-xl p-3 bg-white">
                        <option value="">Choose payment method</option>
                        <option value="GCash">GCash</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                        <option value="Cash">Cash</option>
                    </select>
                </div>

                <div>
                    <label for="payment_type" class="block font-semibold mb-2">Payment Type</label>
                    <select name="payment_type" id="payment_type" required class="w-full border border-slate-300 rounded-xl p-3 bg-white">
                        <option value="">Choose payment type</option>
                        <option value="Down payment">Down payment</option>
                        <option value="Final payment">Final payment</option>
                    </select>
                </div>

                <div class="md:col-span-2">
                    <label for="proof_file" class="block font-semibold mb-2">Payment Receipt / Proof</label>
                    <input type="file" name="proof_file" id="proof_file" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" required class="w-full border border-slate-300 rounded-xl p-3 bg-white">
                    <p class="text-xs text-slate-500 mt-2">Accepted formats: JPG, PNG, WEBP. Maximum size: 5 MB.</p>
                </div>

                <div class="md:col-span-2">
                    <button type="submit" class="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-3 rounded-xl transition">
                        <i data-lucide="upload" class="w-5 h-5"></i>
                        Submit Payment Proof
                    </button>
                </div>

            </form>

        <?php else: ?>

            <div class="bg-slate-50 border border-slate-200 rounded-xl p-5">
                <p class="font-semibold">No available order balances.</p>
                <p class="text-sm text-slate-500 mt-1">
                    An order with an accepted quotation and outstanding balance will appear here.
                </p>
            </div>

        <?php endif; ?>

    </section>

    <!-- Order Balances -->
    <section class="bg-white rounded-xl shadow-sm border border-slate-200 p-5 mb-8">

        <h3 class="text-lg font-bold mb-4">Order Balances</h3>

        <?php if ($balance_result->num_rows > 0): ?>

            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left">
                    <thead class="bg-slate-50 text-slate-600">
                        <tr>
                            <th class="p-3">Order ID</th>
                            <th class="p-3">Order Date</th>
                            <th class="p-3">Quotation Amount</th>
                            <th class="p-3">Total Paid</th>
                            <th class="p-3">Pending Verification</th>
                            <th class="p-3">Remaining Balance</th>
                            <th class="p-3">Order Status</th>
                        </tr>
                    </thead>

                    <tbody class="divide-y divide-slate-100">
                        <?php while ($order = $balance_result->fetch_assoc()): ?>
                            <?php
                                $remaining = max(
                                    0,
                                    (float)$order["quotation_amount"] -
                                    (float)$order["total_paid"]
                                );
                            ?>
                            <tr>
                                <td class="p-3 font-semibold">#<?= (int)$order["order_id"] ?></td>
                                <td class="p-3"><?= htmlspecialchars(date("M d, Y", strtotime($order["order_date"]))) ?></td>
                                <td class="p-3"><?= peso($order["quotation_amount"]) ?></td>
                                <td class="p-3 text-green-700 font-semibold"><?= peso($order["total_paid"]) ?></td>
                                <td class="p-3 text-amber-700 font-semibold"><?= peso($order["pending_amount"]) ?></td>
                                <td class="p-3 font-semibold <?= $remaining > 0 ? 'text-amber-700' : 'text-green-700' ?>"><?= peso($remaining) ?></td>
                                <td class="p-3"><?= htmlspecialchars($order["order_status"]) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

        <?php else: ?>

            <p class="text-slate-500 py-4">No accepted quotations or order balances are available yet.</p>

        <?php endif; ?>

    </section>

    <!-- Submitted Payment Proofs -->
    <section class="bg-white rounded-xl shadow-sm border border-slate-200 p-5 mb-8">

        <h3 class="text-lg font-bold mb-4">My Payment Submissions</h3>

        <?php if ($submissions_result->num_rows > 0): ?>

            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left">
                    <thead class="bg-slate-50 text-slate-600">
                        <tr>
                            <th class="p-3">Submission ID</th>
                            <th class="p-3">Order ID</th>
                            <th class="p-3">Amount</th>
                            <th class="p-3">Method</th>
                            <th class="p-3">Type</th>
                            <th class="p-3">Proof</th>
                            <th class="p-3">Status</th>
                            <th class="p-3">Staff Note</th>
                        </tr>
                    </thead>

                    <tbody class="divide-y divide-slate-100">
                        <?php while ($submission = $submissions_result->fetch_assoc()): ?>
                            <tr>
                                <td class="p-3">#<?= (int)$submission["submission_id"] ?></td>
                                <td class="p-3 font-semibold">#<?= (int)$submission["order_id"] ?></td>
                                <td class="p-3 font-bold"><?= peso($submission["amount"]) ?></td>
                                <td class="p-3"><?= htmlspecialchars($submission["payment_method"]) ?></td>
                                <td class="p-3"><?= htmlspecialchars($submission["payment_type"]) ?></td>
                                <td class="p-3">
                                    <a href="../<?= htmlspecialchars($submission["proof_file"]) ?>" target="_blank" rel="noopener noreferrer" class="text-indigo-600 hover:underline font-semibold">
                                        View proof
                                    </a>
                                </td>
                                <td class="p-3">
                                    <?php if ($submission["status"] === "Approved"): ?>
                                        <span class="text-green-700 font-semibold">Approved</span>
                                    <?php elseif ($submission["status"] === "Rejected"): ?>
                                        <span class="text-red-700 font-semibold">Rejected</span>
                                    <?php else: ?>
                                        <span class="text-amber-700 font-semibold">Pending Verification</span>
                                    <?php endif; ?>
                                </td>
                                <td class="p-3"><?= htmlspecialchars($submission["staff_note"] ?? "") ?: "—" ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

        <?php else: ?>

            <p class="text-slate-500 py-4">You have not submitted any payment proofs yet.</p>

        <?php endif; ?>

    </section>

    <!-- Recorded Payments -->
    <section class="bg-white rounded-xl shadow-sm border border-slate-200 p-5">

        <h3 class="text-lg font-bold mb-4">Recorded Payments</h3>

        <?php if ($result->num_rows > 0): ?>

            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left">
                    <thead class="bg-slate-50 text-slate-600">
                        <tr>
                            <th class="p-3">Payment ID</th>
                            <th class="p-3">Order ID</th>
                            <th class="p-3">Amount Paid</th>
                            <th class="p-3">Payment Type</th>
                            <th class="p-3">Payment Method</th>
                            <th class="p-3">Payment Date</th>
                        </tr>
                    </thead>

                    <tbody class="divide-y divide-slate-100">
                        <?php while ($payment = $result->fetch_assoc()): ?>
                            <tr>
                                <td class="p-3">#<?= (int)$payment["payment_id"] ?></td>
                                <td class="p-3 font-semibold">#<?= (int)$payment["order_id"] ?></td>
                                <td class="p-3 text-green-700 font-bold"><?= peso($payment["amount_paid"]) ?></td>
                                <td class="p-3"><?= htmlspecialchars($payment["payment_type"]) ?></td>
                                <td class="p-3"><?= htmlspecialchars($payment["payment_method"]) ?></td>
                                <td class="p-3"><?= htmlspecialchars(date("M d, Y h:i A", strtotime($payment["payment_date"]))) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

        <?php else: ?>

            <div class="text-center py-10">
                <h4 class="font-semibold text-slate-700">No payments recorded yet</h4>
                <p class="text-slate-500 text-sm mt-2">
                    Approved payment submissions will appear here after Staff records them.
                </p>
            </div>

        <?php endif; ?>

    </section>

</main>

<script>
    lucide.createIcons();
</script>

</body>
</html>

<?php
$stmt->close();
$balance_stmt->close();
$orders_stmt->close();
$submissions_stmt->close();
$conn->close();
?>
