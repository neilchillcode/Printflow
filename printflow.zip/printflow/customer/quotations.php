
<?php
session_start();

require_once "../config/database.php";

// Customer access only
if (
    !isset($_SESSION["customer_id"]) ||
    !isset($_SESSION["user_role"]) ||
    $_SESSION["user_role"] !== "customer"
) {
    header("Location: ../login.php");
    exit;
}

// CSRF token
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$message = "";
$message_type = "";

// Process customer's quotation decision
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (
        !isset($_POST["csrf_token"]) ||
        !hash_equals($_SESSION["csrf_token"], $_POST["csrf_token"])
    ) {
        $message = "Invalid request. Please refresh the page.";
        $message_type = "error";

    } else {

        $quotation_id = filter_input(INPUT_POST, "quotation_id", FILTER_VALIDATE_INT);
        $decision = $_POST["decision"] ?? "";

        $allowed_decisions = [
            "Accepted",
            "Rejected",
            "Revised"
        ];

        if (!$quotation_id || !in_array($decision, $allowed_decisions, true)) {
            $message = "Invalid quotation request.";
            $message_type = "error";

        } else {

            $check = $conn->prepare("
                SELECT q.quotation_id, q.order_id, q.amount
                FROM quotations q
                INNER JOIN orders o ON q.order_id = o.order_id
                WHERE q.quotation_id = ?
                AND o.customer_id = ?
                AND q.status = 'Pending'
            ");

            $customer_id = $_SESSION["customer_id"];

            $check->bind_param("ii", $quotation_id, $customer_id);
            $check->execute();

            $result = $check->get_result();
            $quotation = $result->fetch_assoc();

            if (!$quotation) {
                $message = "Quotation not found or it has already been reviewed.";
                $message_type = "error";

            } else {

                try {
                    $conn->begin_transaction();

                    $update = $conn->prepare("
                        UPDATE quotations
                        SET status = ?
                        WHERE quotation_id = ?
                        AND status = 'Pending'
                    ");

                    $update->bind_param("si", $decision, $quotation_id);
                    $update->execute();

                    if ($update->affected_rows !== 1) {
                        throw new Exception("Quotation status could not be updated.");
                    }

                    $update->close();

                    if ($decision === "Accepted") {

                        $accepted_amount = (float)$quotation["amount"];

                        $order_update = $conn->prepare("
                            UPDATE orders
                            SET total_amount = ?,
                                order_status = 'Design Approval'
                            WHERE order_id = ?
                            AND customer_id = ?
                        ");

                        $order_update->bind_param(
                            "dii",
                            $accepted_amount,
                            $quotation["order_id"],
                            $customer_id
                        );

                        $order_update->execute();

                        if ($order_update->affected_rows < 0) {
                            throw new Exception("Order total could not be updated.");
                        }

                        $order_update->close();
                    }

                    $conn->commit();

                    if ($decision === "Accepted") {
                        $message = "You accepted the quotation. The order total has been updated and your order can now proceed to design approval.";
                    } elseif ($decision === "Rejected") {
                        $message = "You rejected the quotation.";
                    } else {
                        $message = "You requested a quotation revision. Our staff can review it and prepare an updated quotation.";
                    }

                    $message_type = "success";

                } catch (Exception $e) {

                    $conn->rollback();

                    $message = "Something went wrong. Please try again.";
                    $message_type = "error";
                }
            }

            $check->close();
        }
    }
}

// Retrieve quotations belonging only to the logged-in customer
$stmt = $conn->prepare("
    SELECT
        q.quotation_id,
        q.order_id,
        q.amount,
        q.date_issued,
        q.status,
        o.order_date,
        o.due_date,
        o.order_status
    FROM quotations q
    INNER JOIN orders o ON q.order_id = o.order_id
    WHERE o.customer_id = ?
    ORDER BY q.quotation_id DESC
");

$customer_id = $_SESSION["customer_id"];
$stmt->bind_param("i", $customer_id);
$stmt->execute();

$quotations = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Quotations | PrintFlow</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Inter', sans-serif;
        }

        a:focus, button:focus {
            outline: 3px solid #818cf8;
            outline-offset: 2px;
        }
    </style>
</head>

<body class="bg-slate-100 min-h-screen text-slate-800">

    <!-- Navigation -->
    <nav class="bg-white border-b border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-4">

            <!-- PrintFlow Logo -->
            <div class="flex items-center gap-3">
                <div class="bg-indigo-600 text-white p-2 rounded-lg">
                    <i data-lucide="printer"></i>
                </div>

                <div>
                    <h1 class="text-xl font-extrabold text-slate-900">PrintFlow</h1>
                    <p class="text-xs text-slate-500">Customer Portal</p>
                </div>
            </div>

            <!-- Customer Navigation -->
            <div class="flex flex-wrap items-center gap-2 text-sm font-semibold">

                <a href="dashboard.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">
                    Dashboard
                </a>

                <a href="orders.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">
                    My Orders
                </a>

                <a href="request_order.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">
                    Request Order
                </a>

                <a href="quotations.php"
                   aria-current="page"
                   class="border border-blue-400 bg-blue-100 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-200">
                    Quotations
                </a>

                <a href="design_proofs.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">
                    Design Proofs
                </a>

                <a href="payments.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">
                    Payments
                </a>

                <a href="feedback.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">
                    Feedback
                </a>

                <a href="../login.php?logout=1"
                   class="border border-blue-200 bg-blue-50 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">
                    Log Out
                </a>

            </div>

        </div>
    </nav>

    <main class="max-w-6xl mx-auto px-5 py-10">

        <div class="mb-8">
            <a href="dashboard.php" class="text-sm font-semibold text-indigo-700 hover:underline">
                ← Back to Dashboard
            </a>

            <h1 class="text-3xl font-extrabold mt-4">My Quotations</h1>

            <p class="text-slate-600 mt-2">
                Review the proposed prices for your custom order requests.
            </p>
        </div>

        <!-- Feedback message -->
        <?php if ($message !== ""): ?>
            <div
                class="mb-6 p-4 rounded-xl border
                <?php echo $message_type === "success"
                    ? "bg-green-50 border-green-200 text-green-800"
                    : "bg-red-50 border-red-200 text-red-800"; ?>"
                role="status"
            >
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <section class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">

            <div class="p-6 border-b border-slate-200">
                <h2 class="text-xl font-bold">Quotation History</h2>
                <p class="text-sm text-slate-500 mt-1">
                    Only quotations associated with your account are displayed.
                </p>
            </div>

            <div class="overflow-x-auto">

                <table class="w-full text-sm text-left">

                    <thead class="bg-slate-50 text-slate-600">
                        <tr>
                            <th class="p-4">Quotation ID</th>
                            <th class="p-4">Order ID</th>
                            <th class="p-4">Date Issued</th>
                            <th class="p-4">Proposed Amount</th>
                            <th class="p-4">Status</th>
                            <th class="p-4">Action</th>
                        </tr>
                    </thead>

                    <tbody class="divide-y divide-slate-100">

                        <?php if ($quotations->num_rows > 0): ?>

                            <?php while ($quotation = $quotations->fetch_assoc()): ?>

                                <?php
                                $status = $quotation["status"];

                                $status_class = "bg-yellow-100 text-yellow-800";

                                if ($status === "Accepted") {
                                    $status_class = "bg-green-100 text-green-800";
                                } elseif ($status === "Rejected") {
                                    $status_class = "bg-red-100 text-red-800";
                                } elseif ($status === "Revised") {
                                    $status_class = "bg-blue-100 text-blue-800";
                                }
                                ?>

                                <tr class="hover:bg-slate-50">

                                    <td class="p-4 font-bold">
                                        #<?php echo $quotation["quotation_id"]; ?>
                                    </td>

                                    <td class="p-4">
                                        #<?php echo $quotation["order_id"]; ?>
                                    </td>

                                    <td class="p-4">
                                        <?php echo date("M d, Y", strtotime($quotation["date_issued"])); ?>
                                    </td>

                                    <td class="p-4 font-bold text-indigo-700">
                                        ₱<?php echo number_format((float)$quotation["amount"], 2); ?>
                                    </td>

                                    <td class="p-4">
                                        <span class="px-3 py-1 rounded-full text-xs font-bold <?php echo $status_class; ?>">
                                            <?php echo htmlspecialchars($status); ?>
                                        </span>
                                    </td>

                                    <td class="p-4 min-w-64">

                                        <?php if ($status === "Pending"): ?>

                                            <form method="POST" action="" class="space-y-2">

                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?php echo htmlspecialchars($_SESSION["csrf_token"]); ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="quotation_id"
                                                    value="<?php echo $quotation["quotation_id"]; ?>"
                                                >

                                                <button
                                                    type="submit"
                                                    name="decision"
                                                    value="Accepted"
                                                    class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 rounded-lg"
                                                >
                                                    Accept Quotation
                                                </button>

                                                <button
                                                    type="submit"
                                                    name="decision"
                                                    value="Revised"
                                                    class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 rounded-lg"
                                                >
                                                    Request Revision
                                                </button>

                                                <button
                                                    type="submit"
                                                    name="decision"
                                                    value="Rejected"
                                                    class="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-2 rounded-lg"
                                                >
                                                    Reject Quotation
                                                </button>

                                            </form>

                                        <?php elseif ($status === "Revised"): ?>

                                            <span class="text-blue-700 font-semibold">
                                                Waiting for staff to revise
                                            </span>

                                        <?php elseif ($status === "Accepted"): ?>

                                            <span class="text-green-700 font-semibold">
                                                You accepted this quotation
                                            </span>

                                        <?php elseif ($status === "Rejected"): ?>

                                            <span class="text-red-700 font-semibold">
                                                You rejected this quotation
                                            </span>

                                        <?php endif; ?>

                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="6" class="p-10 text-center text-slate-500">
                                    You do not have any quotations yet.
                                    <p class="mt-2">
                                        Once staff prepares a quotation for your order, it will appear here.
                                    </p>
                                </td>
                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </section>

    </main>

    <script>
        lucide.createIcons();
    </script>

</body>
</html>
