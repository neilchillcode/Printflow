
<?php

session_start();

require_once "../config/database.php";

// Check if the user is a logged-in customer
if (
    !isset($_SESSION["customer_id"]) ||
    !isset($_SESSION["user_role"]) ||
    $_SESSION["user_role"] !== "customer"
) {
    header("Location: ../login.php");
    exit;
}

$customer_id = $_SESSION["customer_id"];
$customer_name = $_SESSION["customer_name"];

// Get total orders
$stmt = $conn->prepare("
    SELECT COUNT(*) AS total_orders
    FROM orders
    WHERE customer_id = ?
");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$total_orders = $stmt->get_result()->fetch_assoc()["total_orders"];

// Get active orders
$stmt = $conn->prepare("
    SELECT COUNT(*) AS active_orders
    FROM orders
    WHERE customer_id = ?
    AND order_status NOT IN ('Completed', 'Released')
");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$active_orders = $stmt->get_result()->fetch_assoc()["active_orders"];

// Get completed orders
$stmt = $conn->prepare("
    SELECT COUNT(*) AS completed_orders
    FROM orders
    WHERE customer_id = ?
    AND order_status IN ('Completed', 'Released')
");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$completed_orders = $stmt->get_result()->fetch_assoc()["completed_orders"];

// Get recent orders
$stmt = $conn->prepare("
    SELECT order_id, order_date, due_date, total_amount, order_status
    FROM orders
    WHERE customer_id = ?
    ORDER BY order_date DESC
    LIMIT 5
");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$recent_orders = $stmt->get_result();

// Get follow-ups that Staff has chosen to share with this customer
$stmt = $conn->prepare("
    SELECT followup_id, follow_up_date, notes, status
    FROM follow_ups
    WHERE customer_id = ? AND customer_visible = 1 AND status = 'Pending'
    ORDER BY follow_up_date DESC, followup_id DESC
");
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$customer_followups = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Customer Dashboard | PrintFlow</title>

    <script src="https://cdn.tailwindcss.com"></script>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <script src="https://unpkg.com/lucide@latest"></script>

    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8fafc;
        }
    </style>
</head>

<body class="min-h-screen text-slate-800">

    <!-- Navigation -->
    <nav class="bg-white border-b border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-4">

            <div class="flex items-center gap-3">
                <div class="bg-indigo-600 text-white p-2 rounded-lg">
                    <i data-lucide="printer"></i>
                </div>

                <div>
                    <h1 class="text-xl font-extrabold text-slate-900">PrintFlow</h1>
                    <p class="text-xs text-slate-500">Customer Portal</p>
                </div>
            </div>

            <!-- Customer Navigation -->
            <div class="flex flex-wrap items-center gap-2 text-sm">

                <a href="dashboard.php"
                   aria-current="page"
                   class="border border-blue-400 bg-blue-100 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-200">
                    Dashboard
                </a>

                <a href="orders.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-100">
                    My Orders
                </a>

                <a href="request_order.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-100">
                    Request Order
                </a>

                <a href="quotations.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-100">
                    Quotations
                </a>

                <a href="design_proofs.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-100">
                    Design Proofs
                </a>

                <a href="payments.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-100">
                    Payments
                </a>

                <a href="feedback.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-100">
                    Feedback
                </a>

                <a href="../login.php?logout=1"
                   class="border border-blue-200 bg-blue-50 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-100">
                    Log Out
                </a>

            </div>

        </div>
    </nav>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 py-8">

        <!-- Welcome Section -->
        <section class="mb-8">
            <p class="text-sm font-semibold text-indigo-600 mb-2">
                CUSTOMER DASHBOARD
            </p>

            <h2 class="text-2xl sm:text-3xl font-extrabold text-slate-900">
                Welcome, <?= htmlspecialchars($customer_name) ?>!
            </h2>

            <p class="text-slate-600 mt-2">
                View your orders and keep track of your printing requests.
            </p>
        </section>

        <!-- Statistics -->
        <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-8">

            <div class="bg-white border border-slate-200 rounded-xl p-6">
                <div class="flex items-center justify-between">
                    <p class="text-sm font-semibold text-slate-500">Total Orders</p>
                    <i data-lucide="shopping-bag" class="text-indigo-600"></i>
                </div>

                <p class="text-3xl font-extrabold mt-4">
                    <?= $total_orders ?>
                </p>
            </div>

            <div class="bg-white border border-slate-200 rounded-xl p-6">
                <div class="flex items-center justify-between">
                    <p class="text-sm font-semibold text-slate-500">Active Orders</p>
                    <i data-lucide="clock" class="text-amber-600"></i>
                </div>

                <p class="text-3xl font-extrabold mt-4">
                    <?= $active_orders ?>
                </p>
            </div>

            <div class="bg-white border border-slate-200 rounded-xl p-6">
                <div class="flex items-center justify-between">
                    <p class="text-sm font-semibold text-slate-500">Completed Orders</p>
                    <i data-lucide="check-circle" class="text-green-600"></i>
                </div>

                <p class="text-3xl font-extrabold mt-4">
                    <?= $completed_orders ?>
                </p>
            </div>

        </section>

        <!-- Customer Notifications / Shared Follow-ups -->
        <section class="bg-white border border-slate-200 rounded-xl p-6 mb-8">
            <div class="flex items-center gap-3 mb-4">
                <div class="bg-blue-100 text-blue-700 p-3 rounded-lg">
                    <i data-lucide="bell"></i>
                </div>
                <div>
                    <h3 class="text-lg font-bold text-slate-900">Customer Notifications</h3>
                    <p class="text-sm text-slate-500">Updates and follow-up messages shared by our staff.</p>
                </div>
            </div>

            <?php if ($customer_followups && $customer_followups->num_rows > 0): ?>
                <div class="space-y-3">
                    <?php while ($followup = $customer_followups->fetch_assoc()): ?>
                        <article class="border border-blue-200 bg-blue-50 rounded-lg p-4">
                            <div class="flex flex-wrap items-center justify-between gap-2 mb-2">
                                <p class="font-semibold text-slate-900">
                                    Follow-up: <?= htmlspecialchars(date("M d, Y", strtotime($followup["follow_up_date"]))) ?>
                                </p>
                                <?php if ($followup["status"] === "Done"): ?>
                                    <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-semibold">Completed</span>
                                <?php else: ?>
                                    <span class="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-xs font-semibold">Pending</span>
                                <?php endif; ?>
                            </div>
                            <p class="text-sm text-slate-700 whitespace-pre-wrap"><?= htmlspecialchars($followup["notes"]) ?></p>
                        </article>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-6 text-slate-500">
                    <i data-lucide="inbox" class="w-8 h-8 mx-auto mb-2"></i>
                    <p class="text-sm">You don't have any new follow-up messages at the moment.</p>
                </div>
            <?php endif; ?>
        </section>

        <!-- Quick Actions -->
        <section class="bg-white border border-slate-200 rounded-xl p-6 mb-8">

            <h3 class="text-lg font-bold text-slate-900 mb-4">
                Quick Access
            </h3>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">

                <a href="orders.php"
                   class="flex items-center gap-4 p-4 border border-slate-200 rounded-lg hover:border-blue-400 hover:bg-blue-50">

                    <div class="bg-indigo-100 text-indigo-700 p-3 rounded-lg">
                        <i data-lucide="package"></i>
                    </div>

                    <div>
                        <p class="font-semibold">My Orders</p>
                        <p class="text-sm text-slate-500">
                            View your order history and progress.
                        </p>
                    </div>
                </a>

                <a href="request_order.php"
                   class="flex items-center gap-4 p-4 border border-slate-200 rounded-lg hover:border-blue-400 hover:bg-blue-50">

                    <div class="bg-blue-100 text-blue-700 p-3 rounded-lg">
                        <i data-lucide="plus-circle"></i>
                    </div>

                    <div>
                        <p class="font-semibold">Request Order</p>
                        <p class="text-sm text-slate-500">
                            Submit a new printing request.
                        </p>
                    </div>
                </a>

                <a href="quotations.php"
                   class="flex items-center gap-4 p-4 border border-slate-200 rounded-lg hover:border-blue-400 hover:bg-blue-50">

                    <div class="bg-amber-100 text-amber-700 p-3 rounded-lg">
                        <i data-lucide="file-text"></i>
                    </div>

                    <div>
                        <p class="font-semibold">Quotations</p>
                        <p class="text-sm text-slate-500">
                            Review and respond to quotations.
                        </p>
                    </div>
                </a>

                <a href="design_proofs.php"
                   class="flex items-center gap-4 p-4 border border-slate-200 rounded-lg hover:border-blue-400 hover:bg-blue-50">

                    <div class="bg-purple-100 text-purple-700 p-3 rounded-lg">
                        <i data-lucide="image"></i>
                    </div>

                    <div>
                        <p class="font-semibold">Design Proofs</p>
                        <p class="text-sm text-slate-500">
                            Review and approve your designs.
                        </p>
                    </div>
                </a>

                <a href="payments.php"
                   class="flex items-center gap-4 p-4 border border-slate-200 rounded-lg hover:border-blue-400 hover:bg-blue-50">

                    <div class="bg-green-100 text-green-700 p-3 rounded-lg">
                        <i data-lucide="wallet"></i>
                    </div>

                    <div>
                        <p class="font-semibold">Payments</p>
                        <p class="text-sm text-slate-500">
                            View your payment records and balances.
                        </p>
                    </div>
                </a>

                <a href="feedback.php"
                   class="flex items-center gap-4 p-4 border border-slate-200 rounded-lg hover:border-blue-400 hover:bg-blue-50">

                    <div class="bg-pink-100 text-pink-700 p-3 rounded-lg">
                        <i data-lucide="message-square"></i>
                    </div>

                    <div>
                        <p class="font-semibold">Feedback</p>
                        <p class="text-sm text-slate-500">
                            Submit feedback or report a concern.
                        </p>
                    </div>
                </a>

            </div>

        </section>

        <!-- Recent Orders -->
        <section class="bg-white border border-slate-200 rounded-xl overflow-hidden">

            <div class="flex flex-wrap items-center justify-between gap-3 p-6 border-b border-slate-200">

                <div>
                    <h3 class="text-lg font-bold text-slate-900">
                        Recent Orders
                    </h3>

                    <p class="text-sm text-slate-500 mt-1">
                        Your five most recent orders.
                    </p>
                </div>

                <a href="orders.php"
                   class="text-indigo-700 font-semibold text-sm hover:underline">
                    View All Orders
                </a>

            </div>

            <div class="overflow-x-auto">

                <table class="w-full text-sm text-left">

                    <thead class="bg-slate-50 text-slate-600">
                        <tr>
                            <th class="px-6 py-4">Order ID</th>
                            <th class="px-6 py-4">Order Date</th>
                            <th class="px-6 py-4">Due Date</th>
                            <th class="px-6 py-4">Total Amount</th>
                            <th class="px-6 py-4">Status</th>
                        </tr>
                    </thead>

                    <tbody class="divide-y divide-slate-100">

                        <?php if ($recent_orders->num_rows > 0): ?>

                            <?php while ($order = $recent_orders->fetch_assoc()): ?>

                                <?php
                                $status_class = "bg-slate-100 text-slate-700";

                                if ($order["order_status"] === "Pending") {
                                    $status_class = "bg-amber-100 text-amber-800";
                                } elseif ($order["order_status"] === "Design Approval") {
                                    $status_class = "bg-purple-100 text-purple-800";
                                } elseif ($order["order_status"] === "In Production") {
                                    $status_class = "bg-blue-100 text-blue-800";
                                } elseif ($order["order_status"] === "Completed") {
                                    $status_class = "bg-green-100 text-green-800";
                                } elseif ($order["order_status"] === "Released") {
                                    $status_class = "bg-emerald-100 text-emerald-800";
                                }
                                ?>

                                <tr>
                                    <td class="px-6 py-4 font-semibold">
                                        #<?= (int)$order["order_id"] ?>
                                    </td>

                                    <td class="px-6 py-4">
                                        <?= htmlspecialchars($order["order_date"]) ?>
                                    </td>

                                    <td class="px-6 py-4">
                                        <?= htmlspecialchars($order["due_date"] ?? "Not set") ?>
                                    </td>

                                    <td class="px-6 py-4 font-semibold">
                                        ₱<?= number_format((float)$order["total_amount"], 2) ?>
                                    </td>

                                    <td class="px-6 py-4">
                                        <span class="inline-block px-3 py-1 rounded-full text-xs font-semibold <?= $status_class ?>">
                                            <?= htmlspecialchars($order["order_status"]) ?>
                                        </span>
                                    </td>
                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="5" class="px-6 py-10 text-center text-slate-500">
                                    You have not placed any orders yet.
                                </td>
                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </section>

        <footer class="text-center text-sm text-slate-500 mt-10">
            PrintFlow Customer Portal
        </footer>

    </main>

    <script>
        lucide.createIcons();
    </script>

</body>
</html>
