
<?php

session_start();

require_once "../config/database.php";

// Allow only logged-in customers
if (
    !isset($_SESSION["customer_id"]) ||
    !isset($_SESSION["user_role"]) ||
    $_SESSION["user_role"] !== "customer"
) {
    header("Location: ../login.php");
    exit;
}

$customer_id = $_SESSION["customer_id"];
$customer_name = $_SESSION["customer_name"];

$message = "";
$message_type = "";

// Create CSRF token
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// Handle feedback submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $submitted_token = $_POST["csrf_token"] ?? "";

    if (!hash_equals($_SESSION["csrf_token"], $submitted_token)) {

        $message = "Invalid request. Please refresh the page and try again.";
        $message_type = "error";

    } else {

        $type = trim($_POST["type"] ?? "");
        $feedback_message = trim($_POST["message"] ?? "");

        $allowed_types = ["Feedback", "Complaint"];

        if (!in_array($type, $allowed_types, true)) {

            $message = "Please select a valid submission type.";
            $message_type = "error";

        } elseif ($feedback_message === "") {

            $message = "Please enter your message.";
            $message_type = "error";

        } elseif (strlen($feedback_message) > 2000) {

            $message = "Your message must not exceed 2,000 characters.";
            $message_type = "error";

        } else {

            $stmt = $conn->prepare("
                INSERT INTO feedback
                (customer_id, type, message, status)
                VALUES (?, ?, ?, 'Open')
            ");

            $stmt->bind_param(
                "iss",
                $customer_id,
                $type,
                $feedback_message
            );

            if ($stmt->execute()) {

                $_SESSION["csrf_token"] = bin2hex(random_bytes(32));

                header("Location: feedback.php?submitted=1");
                exit;

            } else {

                $message = "Unable to submit your message. Please try again.";
                $message_type = "error";

            }

            $stmt->close();
        }
    }
}

// Display success message after redirect
if (isset($_GET["submitted"])) {
    $message = "Your message has been submitted successfully!";
    $message_type = "success";
}

// Get feedback submitted by this customer only
$stmt = $conn->prepare("
    SELECT feedback_id, type, message, status, date_submitted
    FROM feedback
    WHERE customer_id = ?
    ORDER BY date_submitted DESC
");

$stmt->bind_param("i", $customer_id);
$stmt->execute();

$feedback_records = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Feedback | PrintFlow</title>

    <script src="https://cdn.tailwindcss.com"></script>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <script src="https://unpkg.com/lucide@latest"></script>

    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8fafc;
        }
    </style>
</head>

<body class="min-h-screen text-slate-800">

    <!-- Navigation -->
    <nav class="bg-white border-b border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-4">

            <!-- PrintFlow Logo -->
            <div class="flex items-center gap-3">

                <div class="bg-indigo-600 text-white p-2 rounded-lg">
                    <i data-lucide="printer"></i>
                </div>

                <div>
                    <h1 class="text-xl font-extrabold text-slate-900">PrintFlow</h1>
                    <p class="text-xs text-slate-500">Customer Portal</p>
                </div>

            </div>

            <!-- Customer Navigation Links -->
            <div class="flex flex-wrap items-center gap-3 text-sm">

                <a href="dashboard.php"
                   class="bg-blue-50 border border-blue-200 text-blue-800 hover:bg-blue-100 px-4 py-2 rounded-lg font-semibold">
                    Dashboard
                </a>

                <a href="orders.php"
                   class="bg-blue-50 border border-blue-200 text-blue-800 hover:bg-blue-100 px-4 py-2 rounded-lg font-semibold">
                    My Orders
                </a>

                <a href="request_order.php"
                   class="bg-blue-50 border border-blue-200 text-blue-800 hover:bg-blue-100 px-4 py-2 rounded-lg font-semibold">
                    Request Order
                </a>

                <a href="quotations.php"
                   class="bg-blue-50 border border-blue-200 text-blue-800 hover:bg-blue-100 px-4 py-2 rounded-lg font-semibold">
                    Quotations
                </a>

                <a href="design_proofs.php"
                   class="bg-blue-50 border border-blue-200 text-blue-800 hover:bg-blue-100 px-4 py-2 rounded-lg font-semibold">
                    Design Proofs
                </a>

                <a href="payments.php"
                   class="bg-blue-50 border border-blue-200 text-blue-800 hover:bg-blue-100 px-4 py-2 rounded-lg font-semibold">
                    Payments
                </a>

                <a href="feedback.php"
                   aria-current="page"
                   class="bg-blue-100 border border-blue-400 text-blue-800 hover:bg-blue-200 px-4 py-2 rounded-lg font-semibold">
                    Feedback
                </a>

                <a href="../login.php?logout=1"
                   class="bg-blue-50 border border-blue-200 text-blue-800 hover:bg-blue-100 px-4 py-2 rounded-lg font-semibold">
                    Log Out
                </a>

            </div>

        </div>
    </nav>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 py-8">

        <!-- Page Heading -->
        <section class="mb-8">

            <p class="text-sm font-semibold text-indigo-600 mb-2">
                CUSTOMER PORTAL
            </p>

            <h2 class="text-2xl sm:text-3xl font-extrabold text-slate-900">
                Feedback and Complaints
            </h2>

            <p class="text-slate-600 mt-2">
                Share your experience or let us know if you have a concern.
            </p>

        </section>

        <!-- Success or Error Message -->
        <?php if ($message !== ""): ?>

            <div
                role="alert"
                class="mb-6 p-4 rounded-lg border
                <?= $message_type === "success"
                    ? "bg-green-50 border-green-200 text-green-800"
                    : "bg-red-50 border-red-200 text-red-800" ?>"
            >
                <?= htmlspecialchars($message) ?>
            </div>

        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

            <!-- Feedback Form -->
            <section class="lg:col-span-1 bg-white border border-slate-200 rounded-xl p-6">

                <h3 class="text-lg font-bold text-slate-900 mb-2">
                    Submit a Message
                </h3>

                <p class="text-sm text-slate-500 mb-6">
                    Your message will be recorded for the shop's staff to review.
                </p>

                <form method="POST" action="feedback.php" class="space-y-5">

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= htmlspecialchars($_SESSION["csrf_token"]) ?>"
                    >

                    <div>

                        <label for="type" class="block text-sm font-semibold mb-2">
                            Submission Type
                        </label>

                        <select
                            id="type"
                            name="type"
                            required
                            class="w-full border border-slate-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                            <option value="">Select a type</option>
                            <option value="Feedback">Feedback</option>
                            <option value="Complaint">Complaint</option>
                        </select>

                    </div>

                    <div>

                        <label for="message" class="block text-sm font-semibold mb-2">
                            Your Message
                        </label>

                        <textarea
                            id="message"
                            name="message"
                            rows="6"
                            maxlength="2000"
                            required
                            placeholder="Write your feedback or concern here..."
                            class="w-full border border-slate-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        ></textarea>

                        <p class="text-xs text-slate-500 mt-2">
                            Maximum of 2,000 characters.
                        </p>

                    </div>

                    <button
                        type="submit"
                        class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                    >
                        Submit Message
                    </button>

                </form>

            </section>

            <!-- Feedback History -->
            <section class="lg:col-span-2 bg-white border border-slate-200 rounded-xl overflow-hidden">

                <div class="p-6 border-b border-slate-200">

                    <h3 class="text-lg font-bold text-slate-900">
                        My Submitted Messages
                    </h3>

                    <p class="text-sm text-slate-500 mt-1">
                        Review the feedback and complaints you have submitted.
                    </p>

                </div>

                <div class="p-6">

                    <?php if ($feedback_records->num_rows > 0): ?>

                        <div class="space-y-4">

                            <?php while ($record = $feedback_records->fetch_assoc()): ?>

                                <?php
                                $status_class = $record["status"] === "Resolved"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-amber-100 text-amber-800";
                                ?>

                                <article class="border border-slate-200 rounded-lg p-5">

                                    <div class="flex flex-wrap items-center justify-between gap-3 mb-3">

                                        <div>

                                            <span class="text-sm font-bold text-slate-900">
                                                <?= htmlspecialchars($record["type"]) ?>
                                            </span>

                                            <p class="text-xs text-slate-500 mt-1">
                                                Submitted:
                                                <?= htmlspecialchars($record["date_submitted"]) ?>
                                            </p>

                                        </div>

                                        <span class="px-3 py-1 rounded-full text-xs font-semibold <?= $status_class ?>">
                                            <?= htmlspecialchars($record["status"]) ?>
                                        </span>

                                    </div>

                                    <p class="text-sm text-slate-700 whitespace-pre-wrap break-words">
                                        <?= htmlspecialchars($record["message"]) ?>
                                    </p>

                                </article>

                            <?php endwhile; ?>

                        </div>

                    <?php else: ?>

                        <div class="text-center py-10">

                            <div class="bg-indigo-50 text-indigo-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-5">
                                <i data-lucide="message-square" class="w-8 h-8"></i>
                            </div>

                            <h4 class="font-bold text-slate-900 mb-2">
                                No Messages Yet
                            </h4>

                            <p class="text-sm text-slate-500">
                                Your submitted feedback and complaints will appear here.
                            </p>

                        </div>

                    <?php endif; ?>

                </div>

            </section>

        </div>

        <footer class="text-center text-sm text-slate-500 mt-10">
            PrintFlow Customer Portal
        </footer>

    </main>

    <script>
        lucide.createIcons();
    </script>

</body>
</html>
