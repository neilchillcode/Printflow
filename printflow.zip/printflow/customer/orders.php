
<?php

session_start();

require_once "../config/database.php";

// Allow only logged-in customers
if (
    !isset($_SESSION["customer_id"]) ||
    !isset($_SESSION["user_role"]) ||
    $_SESSION["user_role"] !== "customer"
) {
    header("Location: ../login.php");
    exit;
}

$customer_id = (int)$_SESSION["customer_id"];
$customer_name = $_SESSION["customer_name"] ?? "Customer";

// Get orders belonging only to the logged-in customer
$stmt = $conn->prepare("
    SELECT order_id, order_date, due_date, total_amount, order_status
    FROM orders
    WHERE customer_id = ?
    ORDER BY order_date DESC
");

$stmt->bind_param("i", $customer_id);
$stmt->execute();

$orders = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Orders | PrintFlow</title>

    <script src="https://cdn.tailwindcss.com"></script>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <script src="https://unpkg.com/lucide@latest"></script>

    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8fafc;
        }

        a:focus {
            outline: 3px solid #818cf8;
            outline-offset: 3px;
        }
    </style>
</head>

<body class="min-h-screen text-slate-800">

    <!-- Navigation -->
    <nav class="bg-white border-b border-slate-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-4">

            <div class="flex items-center gap-3">
                <div class="bg-indigo-600 text-white p-2 rounded-lg">
                    <i data-lucide="printer"></i>
                </div>

                <div>
                    <h1 class="text-xl font-extrabold text-slate-900">PrintFlow</h1>
                    <p class="text-xs text-slate-500">Customer Portal</p>
                </div>
            </div>

            <!-- Customer Navigation -->
            <div class="flex flex-wrap items-center gap-2 text-sm">

                <a href="dashboard.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-100">
                    Dashboard
                </a>

                <a href="orders.php"
                   aria-current="page"
                   class="border border-blue-400 bg-blue-100 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-200">
                    My Orders
                </a>

                <a href="request_order.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-100">
                    Request Order
                </a>

                <a href="quotations.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-100">
                    Quotations
                </a>

                <a href="design_proofs.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-100">
                    Design Proofs
                </a>

                <a href="payments.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-100">
                    Payments
                </a>

                <a href="feedback.php"
                   class="border border-blue-200 bg-blue-50 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-100">
                    Feedback
                </a>

                <a href="../login.php?logout=1"
                   class="border border-blue-200 bg-blue-50 text-blue-800 font-semibold px-4 py-2 rounded-lg hover:bg-blue-100">
                    Log Out
                </a>

            </div>
        </div>
    </nav>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 py-8">

        <!-- Page Heading -->
        <section class="mb-8">

            <p class="text-sm font-semibold text-indigo-600 mb-2">
                CUSTOMER PORTAL
            </p>

            <h2 class="text-2xl sm:text-3xl font-extrabold text-slate-900">
                My Orders
            </h2>

            <p class="text-slate-600 mt-2">
                Hello, <?= htmlspecialchars($customer_name) ?>!
                View your orders and monitor their progress.
            </p>

        </section>

        <!-- Production Stage Information -->
        <section class="bg-indigo-50 border border-indigo-100 rounded-xl p-5 mb-8">

            <h3 class="font-bold text-indigo-900 mb-2">
                Understanding Production Progress
            </h3>

            <p class="text-sm text-indigo-800">
                Your products move through four production stages:
                Queued, Printing, Quality Check, and Done.
                During Quality Check, Staff records whether the product passed or failed inspection.
                Products that fail inspection return to Printing for rework before another quality check.
            </p>

        </section>

        <!-- Order List -->
        <?php if ($orders->num_rows > 0): ?>

            <div class="space-y-6">

                <?php while ($order = $orders->fetch_assoc()): ?>

                    <?php
                    // Get the order status color
                    $status_class = "bg-slate-100 text-slate-700";

                    if ($order["order_status"] === "Pending") {
                        $status_class = "bg-amber-100 text-amber-800";
                    } elseif ($order["order_status"] === "Design Approval") {
                        $status_class = "bg-purple-100 text-purple-800";
                    } elseif ($order["order_status"] === "In Production") {
                        $status_class = "bg-blue-100 text-blue-800";
                    } elseif ($order["order_status"] === "Completed") {
                        $status_class = "bg-green-100 text-green-800";
                    } elseif ($order["order_status"] === "Released") {
                        $status_class = "bg-emerald-100 text-emerald-800";
                    }

                    // Get products, their latest production updates,
                    // and their most recent quality-check results.
                    $item_stmt = $conn->prepare("
                        SELECT
                            oi.item_id,
                            p.product_name,
                            oi.size,
                            oi.color,
                            oi.material,
                            oi.quantity,
                            oi.design_notes,

                            latest.stage,
                            latest.remarks,
                            latest.log_date,

                            latest_quality.quality_result,
                            latest_quality.quality_date

                        FROM order_items oi

                        INNER JOIN products p
                            ON oi.product_id = p.product_id

                        LEFT JOIN (
                            SELECT
                                pl.item_id,
                                pl.stage,
                                pl.remarks,
                                pl.log_date
                            FROM production_logs pl

                            INNER JOIN (
                                SELECT
                                    item_id,
                                    MAX(log_id) AS latest_log_id
                                FROM production_logs
                                GROUP BY item_id
                            ) latest_log
                                ON pl.log_id = latest_log.latest_log_id

                        ) latest
                            ON oi.item_id = latest.item_id

                        LEFT JOIN (
                            SELECT
                                qc.item_id,
                                qc.quality_result,
                                qc.log_date AS quality_date
                            FROM production_logs qc

                            INNER JOIN (
                                SELECT
                                    item_id,
                                    MAX(log_id) AS latest_quality_log_id
                                FROM production_logs
                                WHERE stage = 'Quality Check'
                                GROUP BY item_id
                            ) latest_qc
                                ON qc.log_id = latest_qc.latest_quality_log_id

                        ) latest_quality
                            ON oi.item_id = latest_quality.item_id

                        WHERE oi.order_id = ?
                        ORDER BY oi.item_id ASC
                    ");

                    $item_stmt->bind_param("i", $order["order_id"]);
                    $item_stmt->execute();

                    $items = $item_stmt->get_result();
                    ?>

                    <!-- Order Card -->
                    <section class="bg-white border border-slate-200 rounded-xl overflow-hidden">

                        <!-- Order Header -->
                        <div class="p-5 sm:p-6 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">

                            <div>
                                <p class="text-sm text-slate-500">Order Number</p>

                                <h3 class="text-xl font-extrabold text-slate-900">
                                    #<?= (int)$order["order_id"] ?>
                                </h3>
                            </div>

                            <span class="inline-block px-4 py-2 rounded-full text-xs font-bold <?= $status_class ?>">
                                <?= htmlspecialchars($order["order_status"]) ?>
                            </span>

                        </div>

                        <!-- Order Information -->
                        <div class="p-5 sm:p-6">

                            <div class="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-6">

                                <div>
                                    <p class="text-sm text-slate-500">Order Date</p>

                                    <p class="font-semibold mt-1">
                                        <?= htmlspecialchars($order["order_date"]) ?>
                                    </p>
                                </div>

                                <div>
                                    <p class="text-sm text-slate-500">Due Date</p>

                                    <p class="font-semibold mt-1">
                                        <?= htmlspecialchars($order["due_date"] ?? "Not set") ?>
                                    </p>
                                </div>

                                <div>
                                    <p class="text-sm text-slate-500">Total Amount</p>

                                    <p class="font-bold text-indigo-700 text-lg mt-1">
                                        ₱<?= number_format((float)$order["total_amount"], 2) ?>
                                    </p>
                                </div>

                            </div>

                            <!-- Products and Production Progress -->
                            <div>

                                <h4 class="font-bold text-slate-900 mb-3">
                                    Order Items and Production Progress
                                </h4>

                                <?php if ($items->num_rows > 0): ?>

                                    <div class="overflow-x-auto border border-slate-200 rounded-lg">

                                        <table class="w-full text-sm text-left">

                                            <thead class="bg-slate-50 text-slate-600">
                                                <tr>
                                                    <th class="px-4 py-3">Product</th>
                                                    <th class="px-4 py-3">Size</th>
                                                    <th class="px-4 py-3">Color</th>
                                                    <th class="px-4 py-3">Material</th>
                                                    <th class="px-4 py-3">Quantity</th>
                                                    <th class="px-4 py-3">Production Progress</th>
                                                </tr>
                                            </thead>

                                            <tbody class="divide-y divide-slate-100">

                                                <?php while ($item = $items->fetch_assoc()): ?>

                                                    <?php
                                                    // Determine production stage appearance
                                                    $stage = $item["stage"] ?? "";

                                                    $stage_class = "bg-slate-100 text-slate-700";

                                                    if ($stage === "Queued") {
                                                        $stage_class = "bg-amber-100 text-amber-800";
                                                    } elseif ($stage === "Printing") {
                                                        $stage_class = "bg-blue-100 text-blue-800";
                                                    } elseif ($stage === "Quality Check") {
                                                        $stage_class = "bg-purple-100 text-purple-800";
                                                    } elseif ($stage === "Done") {
                                                        $stage_class = "bg-green-100 text-green-800";
                                                    }

                                                    // Determine quality result appearance
                                                    $quality_result = $item["quality_result"] ?? "";

                                                    $quality_class = "bg-slate-100 text-slate-700";

                                                    if ($quality_result === "Pass") {
                                                        $quality_class = "bg-emerald-100 text-emerald-800";
                                                    } elseif ($quality_result === "Fail") {
                                                        $quality_class = "bg-red-100 text-red-800";
                                                    }
                                                    ?>

                                                    <tr>

                                                        <td class="px-4 py-3 font-semibold">
                                                            <?= htmlspecialchars($item["product_name"]) ?>
                                                        </td>

                                                        <td class="px-4 py-3">
                                                            <?= htmlspecialchars($item["size"] ?: "Not specified") ?>
                                                        </td>

                                                        <td class="px-4 py-3">
                                                            <?= htmlspecialchars($item["color"] ?: "Not specified") ?>
                                                        </td>

                                                        <td class="px-4 py-3">
                                                            <?= htmlspecialchars($item["material"] ?: "Not specified") ?>
                                                        </td>

                                                        <td class="px-4 py-3">
                                                            <?= (int)$item["quantity"] ?>
                                                        </td>

                                                        <td class="px-4 py-3 min-w-52">

                                                            <?php if ($stage !== ""): ?>

                                                                <!-- Current Production Stage -->
                                                                <span class="inline-block px-3 py-1 rounded-full text-xs font-bold <?= $stage_class ?>">
                                                                    <?= htmlspecialchars($stage) ?>
                                                                </span>

                                                                <!-- Latest Quality Check Result -->
                                                                <?php if ($quality_result !== ""): ?>

                                                                    <div class="mt-3">

                                                                        <p class="text-xs font-semibold text-slate-600 mb-1">
                                                                            Latest Quality Check
                                                                        </p>

                                                                        <span class="inline-block px-3 py-1 rounded-full text-xs font-bold <?= $quality_class ?>">
                                                                            <?= htmlspecialchars($quality_result) ?>
                                                                        </span>

                                                                        <?php if (!empty($item["quality_date"])): ?>

                                                                            <p class="text-xs text-slate-500 mt-1">
                                                                                Checked:
                                                                                <?= htmlspecialchars(date(
                                                                                    "M d, Y h:i A",
                                                                                    strtotime($item["quality_date"])
                                                                                )) ?>
                                                                            </p>

                                                                        <?php endif; ?>

                                                                        <?php if ($quality_result === "Fail" && $stage === "Printing"): ?>

                                                                            <p class="text-xs text-amber-700 mt-2 font-semibold">
                                                                                Product returned for rework.
                                                                            </p>

                                                                        <?php elseif ($quality_result === "Fail" && $stage === "Quality Check"): ?>

                                                                            <p class="text-xs text-red-700 mt-2 font-semibold">
                                                                                Product failed inspection.
                                                                            </p>

                                                                        <?php elseif ($quality_result === "Pass" && $stage === "Done"): ?>

                                                                            <p class="text-xs text-emerald-700 mt-2 font-semibold">
                                                                                Product passed inspection.
                                                                            </p>

                                                                        <?php endif; ?>

                                                                    </div>

                                                                <?php endif; ?>

                                                                <!-- Last Production Update -->
                                                                <?php if (!empty($item["log_date"])): ?>

                                                                    <p class="text-xs text-slate-500 mt-3">
                                                                        Last updated:
                                                                        <?= htmlspecialchars(date(
                                                                            "M d, Y h:i A",
                                                                            strtotime($item["log_date"])
                                                                        )) ?>
                                                                    </p>

                                                                <?php endif; ?>

                                                                <!-- Staff Remarks -->
                                                                <?php if (!empty($item["remarks"])): ?>

                                                                    <p class="text-xs text-slate-600 mt-2 whitespace-pre-wrap">
                                                                        <strong>Staff Remarks:</strong>
                                                                        <?= htmlspecialchars($item["remarks"]) ?>
                                                                    </p>

                                                                <?php endif; ?>

                                                            <?php else: ?>

                                                                <span class="inline-block px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-600">
                                                                    Not started
                                                                </span>

                                                                <p class="text-xs text-slate-500 mt-2">
                                                                    No production update yet.
                                                                </p>

                                                            <?php endif; ?>

                                                        </td>

                                                    </tr>

                                                    <?php if (!empty($item["design_notes"])): ?>

                                                        <tr>
                                                            <td colspan="6" class="px-4 py-3 bg-slate-50 text-slate-600">
                                                                <strong>Design Notes:</strong>
                                                                <?= htmlspecialchars($item["design_notes"]) ?>
                                                            </td>
                                                        </tr>

                                                    <?php endif; ?>

                                                <?php endwhile; ?>

                                            </tbody>

                                        </table>

                                    </div>

                                <?php else: ?>

                                    <p class="text-sm text-slate-500">
                                        No product details are available for this order.
                                    </p>

                                <?php endif; ?>

                            </div>

                        </div>

                    </section>

                    <?php $item_stmt->close(); ?>

                <?php endwhile; ?>

            </div>

        <?php else: ?>

            <!-- Empty State -->
            <section class="bg-white border border-slate-200 rounded-xl p-10 text-center">

                <div class="bg-indigo-50 text-indigo-600 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-5">
                    <i data-lucide="package" class="w-8 h-8"></i>
                </div>

                <h3 class="text-xl font-bold text-slate-900 mb-2">
                    No Orders Yet
                </h3>

                <p class="text-slate-500 max-w-md mx-auto">
                    You haven't placed any orders yet.
                    Your orders will appear here once they have been recorded.
                </p>

            </section>

        <?php endif; ?>

        <footer class="text-center text-sm text-slate-500 mt-10">
            PrintFlow Customer Portal
        </footer>

    </main>

    <script>
        lucide.createIcons();
    </script>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
