
<?php
session_start();

require_once "../config/database.php";

// Customer access only
if (
    !isset($_SESSION["customer_id"]) ||
    !isset($_SESSION["user_role"]) ||
    $_SESSION["user_role"] !== "customer"
) {
    header("Location: ../login.php");
    exit;
}

// CSRF protection
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$message = "";
$message_type = "";
$awaiting_downpayment = false;

// Process customer approval or revision request
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (
        !isset($_POST["csrf_token"]) ||
        !hash_equals($_SESSION["csrf_token"], $_POST["csrf_token"])
    ) {
        $message = "Invalid request. Please refresh the page.";
        $message_type = "error";

    } else {

        $proof_id = filter_input(INPUT_POST, "proof_id", FILTER_VALIDATE_INT);
        $decision = $_POST["decision"] ?? "";
        $remarks = trim($_POST["customer_remarks"] ?? "");

        if (
            !$proof_id ||
            !in_array($decision, ["Approved", "Revision Requested"], true)
        ) {
            $message = "Invalid design proof request.";
            $message_type = "error";

        } elseif (strlen($remarks) > 2000) {
            $message = "Your remarks must not exceed 2,000 characters.";
            $message_type = "error";

        } elseif ($decision === "Revision Requested" && $remarks === "") {
            $message = "Please explain what changes you would like.";
            $message_type = "error";

        } else {

            $customer_id = $_SESSION["customer_id"];

            // Confirm that this is the customer's latest pending proof
            $check = $conn->prepare("
                SELECT
                    dp.proof_id,
                    dp.item_id,
                    oi.order_id
                FROM design_proofs dp
                INNER JOIN order_items oi ON dp.item_id = oi.item_id
                INNER JOIN orders o ON oi.order_id = o.order_id
                WHERE dp.proof_id = ?
                AND o.customer_id = ?
                AND dp.approval_status = 'Pending'
                AND dp.version_no = (
                    SELECT MAX(dp2.version_no)
                    FROM design_proofs dp2
                    WHERE dp2.item_id = dp.item_id
                )
            ");

            $check->bind_param("ii", $proof_id, $customer_id);
            $check->execute();

            $result = $check->get_result();
            $proof = $result->fetch_assoc();

            if (!$proof) {
                $message = "Design proof not found or it has already been reviewed.";
                $message_type = "error";

            } else {

                try {
                    $conn->begin_transaction();

                    // Update proof approval status and customer remarks
                    $update = $conn->prepare("
                        UPDATE design_proofs
                        SET approval_status = ?,
                            customer_remarks = ?,
                            date_approved = ?
                        WHERE proof_id = ?
                    ");

                    $date_approved = ($decision === "Approved")
                        ? date("Y-m-d H:i:s")
                        : null;

                    $update->bind_param(
                        "sssi",
                        $decision,
                        $remarks,
                        $date_approved,
                        $proof_id
                    );

                    $update->execute();
                    $update->close();

                    // If every order item has an approved latest proof,
                    // move the order into production.
                    if ($decision === "Approved") {

                        $completion_check = $conn->prepare("
                            SELECT
                                COUNT(oi.item_id) AS total_items,
                                SUM(
                                    CASE
                                        WHEN latest.approval_status = 'Approved'
                                        THEN 1
                                        ELSE 0
                                    END
                                ) AS approved_items
                            FROM order_items oi
                            LEFT JOIN (
                                SELECT dp1.item_id, dp1.approval_status
                                FROM design_proofs dp1
                                INNER JOIN (
                                    SELECT item_id, MAX(version_no) AS latest_version
                                    FROM design_proofs
                                    GROUP BY item_id
                                ) versions
                                ON dp1.item_id = versions.item_id
                                AND dp1.version_no = versions.latest_version
                            ) latest ON oi.item_id = latest.item_id
                            WHERE oi.order_id = ?
                        ");

                        $completion_check->bind_param(
                            "i",
                            $proof["order_id"]
                        );

                        $completion_check->execute();

                        $completion_result = $completion_check->get_result();
                        $completion = $completion_result->fetch_assoc();

                        if (
                            (int)$completion["total_items"] > 0 &&
                            (int)$completion["total_items"] === (int)$completion["approved_items"]
                        ) {

                            // Production may begin only after a down payment is recorded.
                            $payment_check = $conn->prepare("
                                SELECT COALESCE(SUM(amount_paid), 0) AS downpayment_total
                                FROM payments
                                WHERE order_id = ?
                                AND payment_type = 'Down payment'
                            ");

                            $payment_check->bind_param("i", $proof["order_id"]);
                            $payment_check->execute();

                            $payment_result = $payment_check->get_result();
                            $payment_row = $payment_result->fetch_assoc();
                            $downpayment_total = (float)$payment_row["downpayment_total"];

                            $payment_check->close();

                            if ($downpayment_total > 0) {
                                $order_update = $conn->prepare("
                                    UPDATE orders
                                    SET order_status = 'In Production'
                                    WHERE order_id = ?
                                    AND customer_id = ?
                                    AND order_status = 'Design Approval'
                                ");

                                $order_update->bind_param(
                                    "ii",
                                    $proof["order_id"],
                                    $customer_id
                                );

                                $order_update->execute();
                                $order_update->close();
                            } else {
                                // Keep the order in Design Approval until staff records the down payment.
                                $awaiting_downpayment = true;
                            }
                        }

                        $completion_check->close();
                    }

                    $conn->commit();

                    if ($decision === "Approved" && $awaiting_downpayment) {
                        $message = "You approved the design proof successfully. The order is waiting for the required down payment before production can begin.";
                    } elseif ($decision === "Approved") {
                        $message = "You approved the design proof successfully.";
                    } else {
                        $message = "Your revision request has been submitted to the staff.";
                    }

                    $message_type = "success";

                } catch (Exception $e) {

                    $conn->rollback();

                    $message = "Something went wrong. Please try again.";
                    $message_type = "error";
                }
            }

            $check->close();
        }
    }
}

// Retrieve design proofs belonging only to the logged-in customer
$stmt = $conn->prepare("
    SELECT
        dp.proof_id,
        dp.item_id,
        dp.file_path,
        dp.version_no,
        dp.approval_status,
        dp.customer_remarks,
        dp.date_submitted,
        dp.date_approved,
        oi.order_id,
        p.product_name
    FROM design_proofs dp
    INNER JOIN order_items oi ON dp.item_id = oi.item_id
    INNER JOIN products p ON oi.product_id = p.product_id
    INNER JOIN orders o ON oi.order_id = o.order_id
    WHERE o.customer_id = ?
    ORDER BY dp.item_id DESC, dp.version_no DESC
");

$customer_id = $_SESSION["customer_id"];
$stmt->bind_param("i", $customer_id);
$stmt->execute();

$proofs = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Design Proof Approval | PrintFlow</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Inter', sans-serif;
        }

        a:focus, button:focus, textarea:focus {
            outline: 3px solid #818cf8;
            outline-offset: 2px;
        }
    </style>
</head>

<body class="bg-slate-100 min-h-screen text-slate-800">

    <!-- Navigation -->
    <nav class="bg-white border-b border-slate-200">
        <div class="max-w-6xl mx-auto px-5 py-4 flex flex-wrap justify-between items-center gap-4">

            <!-- PrintFlow Logo -->
            <a href="dashboard.php" class="flex items-center gap-3">
                <div class="bg-indigo-600 text-white p-2 rounded-lg">
                    <i data-lucide="printer"></i>
                </div>

                <div>
                    <h1 class="text-xl font-extrabold text-slate-900">PrintFlow</h1>
                    <p class="text-xs text-slate-500">Customer Portal</p>
                </div>
            </a>

            <!-- Customer Navigation Links -->
            <div class="flex flex-wrap gap-2 text-sm font-semibold">

                <a href="dashboard.php"
                   class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">
                    Dashboard
                </a>

                <a href="orders.php"
                   class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">
                    My Orders
                </a>

                <a href="request_order.php"
                   class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">
                    Request Order
                </a>

                <a href="quotations.php"
                   class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">
                    Quotations
                </a>

                <a href="design_proofs.php"
                   class="bg-blue-100 border border-blue-400 text-blue-900 px-4 py-2 rounded-lg hover:bg-blue-200">
                    Design Proofs
                </a>

                <a href="payments.php"
                   class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">
                    Payments
                </a>

                <a href="feedback.php"
                   class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">
                    Feedback
                </a>

                <a href="../login.php?logout=1"
                   class="bg-blue-50 border border-blue-200 text-blue-800 px-4 py-2 rounded-lg hover:bg-blue-100">
                    Log Out
                </a>

            </div>

        </div>
    </nav>

    <main class="max-w-6xl mx-auto px-5 py-10">

        <div class="mb-8">
            <a href="dashboard.php" class="text-sm font-semibold text-indigo-700 hover:underline">
                ← Back to Dashboard
            </a>

            <h1 class="text-3xl font-extrabold mt-4">Design Proof Approvals</h1>

            <p class="text-slate-600 mt-2">
                Review the designs prepared for your orders and approve them or request changes.
            </p>
        </div>

        <!-- Feedback message -->
        <?php if ($message !== ""): ?>
            <div
                class="mb-6 p-4 rounded-xl border
                <?php echo $message_type === "success"
                    ? "bg-green-50 border-green-200 text-green-800"
                    : "bg-red-50 border-red-200 text-red-800"; ?>"
                role="status"
            >
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <!-- Design proof list -->
        <section class="space-y-6">

            <?php if ($proofs->num_rows > 0): ?>

                <?php while ($proof = $proofs->fetch_assoc()): ?>

                    <?php
                    $status = $proof["approval_status"];

                    $status_class = "bg-yellow-100 text-yellow-800";

                    if ($status === "Approved") {
                        $status_class = "bg-green-100 text-green-800";
                    } elseif ($status === "Revision Requested") {
                        $status_class = "bg-blue-100 text-blue-800";
                    }

                    $file_url = "../" . $proof["file_path"];
                    $extension = strtolower(pathinfo($proof["file_path"], PATHINFO_EXTENSION));

                    // Check whether this is the latest proof version
                    $latest_check = $conn->prepare("
                        SELECT MAX(version_no) AS latest_version
                        FROM design_proofs
                        WHERE item_id = ?
                    ");

                    $latest_check->bind_param("i", $proof["item_id"]);
                    $latest_check->execute();

                    $latest_result = $latest_check->get_result();
                    $latest_row = $latest_result->fetch_assoc();

                    $is_latest = ((int)$proof["version_no"] === (int)$latest_row["latest_version"]);

                    $latest_check->close();
                    ?>

                    <article class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">

                        <div class="p-6 border-b border-slate-200 flex flex-wrap justify-between items-center gap-3">

                            <div>
                                <h2 class="text-lg font-bold">
                                    Order #<?php echo $proof["order_id"]; ?>
                                </h2>

                                <p class="text-sm text-slate-600 mt-1">
                                    <?php echo htmlspecialchars($proof["product_name"]); ?>
                                    · Version <?php echo $proof["version_no"]; ?>
                                </p>
                            </div>

                            <span class="px-3 py-1 rounded-full text-xs font-bold <?php echo $status_class; ?>">
                                <?php echo htmlspecialchars($status); ?>
                            </span>

                        </div>

                        <div class="p-6">

                            <p class="text-sm text-slate-500 mb-4">
                                Submitted:
                                <?php echo date("M d, Y h:i A", strtotime($proof["date_submitted"])); ?>
                            </p>

                            <!-- Image preview -->
                            <?php if (in_array($extension, ["jpg", "jpeg", "png"], true)): ?>

                                <div class="mb-6 bg-slate-50 border border-slate-200 rounded-xl p-3">
                                    <img
                                        src="<?php echo htmlspecialchars($file_url); ?>"
                                        alt="Design proof for Order <?php echo $proof["order_id"]; ?>"
                                        class="max-h-96 mx-auto object-contain"
                                    >
                                </div>

                            <?php else: ?>

                                <div class="mb-6 p-5 bg-slate-50 border border-slate-200 rounded-xl">
                                    <p class="font-semibold mb-2">PDF Design Proof</p>

                                    <a
                                        href="<?php echo htmlspecialchars($file_url); ?>"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        class="text-indigo-700 font-bold underline"
                                    >
                                        Open PDF Design Proof
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if (!empty($proof["customer_remarks"])): ?>
                                <div class="mb-5 p-4 bg-slate-50 rounded-xl">
                                    <p class="font-bold text-sm mb-1">Previous remarks</p>
                                    <p class="text-sm text-slate-600">
                                        <?php echo nl2br(htmlspecialchars($proof["customer_remarks"])); ?>
                                    </p>
                                </div>
                            <?php endif; ?>

                            <!-- Approval actions -->
                            <?php if ($status === "Pending" && $is_latest): ?>

                                <form method="POST" action="">

                                    <input
                                        type="hidden"
                                        name="csrf_token"
                                        value="<?php echo htmlspecialchars($_SESSION["csrf_token"]); ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="proof_id"
                                        value="<?php echo $proof["proof_id"]; ?>"
                                    >

                                    <div class="mb-4">
                                        <label
                                            for="remarks_<?php echo $proof["proof_id"]; ?>"
                                            class="block font-bold mb-2"
                                        >
                                            Remarks or requested changes
                                        </label>

                                        <textarea
                                            name="customer_remarks"
                                            id="remarks_<?php echo $proof["proof_id"]; ?>"
                                            rows="3"
                                            maxlength="2000"
                                            placeholder="If you need changes, explain them here."
                                            class="w-full border border-slate-300 rounded-lg p-3"
                                        ></textarea>
                                    </div>

                                    <div class="flex flex-wrap gap-3">

                                        <button
                                            type="submit"
                                            name="decision"
                                            value="Approved"
                                            class="bg-green-600 hover:bg-green-700 text-white font-bold px-6 py-3 rounded-lg"
                                        >
                                            Approve Design
                                        </button>

                                        <button
                                            type="submit"
                                            name="decision"
                                            value="Revision Requested"
                                            class="bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-3 rounded-lg"
                                        >
                                            Request Revision
                                        </button>

                                    </div>

                                </form>

                            <?php elseif (!$is_latest): ?>

                                <p class="text-sm text-slate-500">
                                    An updated design proof is available. Please review the latest version.
                                </p>

                            <?php elseif ($status === "Approved"): ?>

                                <p class="text-green-700 font-semibold">
                                    You approved this design proof.
                                </p>

                            <?php elseif ($status === "Revision Requested"): ?>

                                <p class="text-blue-700 font-semibold">
                                    Your revision request has been submitted. Please wait for an updated design.
                                </p>

                            <?php endif; ?>

                        </div>

                    </article>

                <?php endwhile; ?>

            <?php else: ?>

                <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-10 text-center">

                    <h2 class="text-xl font-bold">No Design Proofs Yet</h2>

                    <p class="text-slate-500 mt-2">
                        Once staff uploads a design proof for your order, it will appear here for review.
                    </p>

                </div>

            <?php endif; ?>

        </section>

    </main>

    <script>
        lucide.createIcons();
    </script>

</body>
</html>
