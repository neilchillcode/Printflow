
<?php

// Redirect customers to the login page
header("Location: login.php");
exit;

?>
