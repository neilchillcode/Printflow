
<?php
session_start();

require_once "../config/database.php";

// Check if user is logged in
if (!isset($_SESSION["user_id"]) || !isset($_SESSION["user_role"])) {
    header("Location: ../login.php");
    exit;
}

// Only Admin can access this page
if (strtolower($_SESSION["user_role"]) !== "admin") {
    header("Location: ../login.php");
    exit;
}

// Create a security token for forms
if (!isset($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION["csrf_token"];

// Available order statuses
$statuses = [
    "Pending",
    "Design Approval",
    "In Production",
    "Completed",
    "Released"
];

// Handle order status updates
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["update_status"])) {

    $order_id = (int)($_POST["order_id"] ?? 0);
    $new_status = $_POST["order_status"] ?? "";
    $submitted_token = $_POST["csrf_token"] ?? "";

    if (!hash_equals($csrf_token, $submitted_token)) {

        header("Location: orders.php?error=security");
        exit;

    } elseif ($order_id <= 0 || !in_array($new_status, $statuses, true)) {

        header("Location: orders.php?error=invalid");
        exit;

    } else {

        // Require full payment before an order can be released.
        if ($new_status === "Released") {

            $quotation_check = $conn->prepare("
                SELECT amount
                FROM quotations
                WHERE order_id = ?
                AND status = 'Accepted'
                LIMIT 1
            ");

            $quotation_check->bind_param("i", $order_id);
            $quotation_check->execute();
            $quotation_result = $quotation_check->get_result();
            $accepted_quotation = $quotation_result->fetch_assoc();
            $quotation_check->close();

            if (!$accepted_quotation) {
                header("Location: orders.php?error=quotation");
                exit;
            }

            $payment_check = $conn->prepare("
                SELECT COALESCE(SUM(amount_paid), 0) AS total_paid
                FROM payments
                WHERE order_id = ?
            ");

            $payment_check->bind_param("i", $order_id);
            $payment_check->execute();
            $payment_result = $payment_check->get_result();
            $payment_row = $payment_result->fetch_assoc();
            $payment_check->close();

            $quotation_amount = (float)$accepted_quotation["amount"];
            $total_paid = (float)$payment_row["total_paid"];

            if ($total_paid + 0.009 < $quotation_amount) {
                header("Location: orders.php?error=balance");
                exit;
            }
        }

        $stmt = $conn->prepare("
            UPDATE orders
            SET order_status = ?
            WHERE order_id = ?
        ");

        $stmt->bind_param("si", $new_status, $order_id);

        if ($stmt->execute()) {
            $stmt->close();

            header("Location: orders.php?updated=1");
            exit;
        } else {
            $stmt->close();

            header("Location: orders.php?error=update");
            exit;
        }
    }
}

// Search orders
$search = trim($_GET["search"] ?? "");
$search_value = "%" . $search . "%";

$stmt = $conn->prepare("
    SELECT
        o.order_id,
        c.full_name,
        o.order_date,
        o.due_date,
        o.order_status,
        o.total_amount,
        COUNT(oi.item_id) AS item_count

    FROM orders o

    INNER JOIN customers c
        ON o.customer_id = c.customer_id

    LEFT JOIN order_items oi
        ON o.order_id = oi.order_id

    WHERE
        CAST(o.order_id AS CHAR) LIKE ?
        OR c.full_name LIKE ?
        OR o.order_status LIKE ?

    GROUP BY
        o.order_id,
        c.full_name,
        o.order_date,
        o.due_date,
        o.order_status,
        o.total_amount

    ORDER BY o.order_id DESC
");

$stmt->bind_param(
    "sss",
    $search_value,
    $search_value,
    $search_value
);

$stmt->execute();

$orders = $stmt->get_result();

$total_displayed = $orders->num_rows;

$admin_name = $_SESSION["user_name"] ?? "Administrator";

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Order Management | PrintFlow</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Inter', sans-serif;
        }

        a:focus,
        button:focus,
        select:focus,
        input:focus {
            outline: 3px solid #818cf8;
            outline-offset: 3px;
        }
    </style>

</head>

<body class="bg-slate-100 text-slate-800 min-h-screen">

    <!-- Header -->
    <header class="bg-white border-b border-slate-200 shadow-sm">

        <div class="max-w-7xl mx-auto px-4 sm:px-6 py-4">

            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">

                <div class="flex items-center gap-3">

                    <div class="w-11 h-11 bg-indigo-600 rounded-xl flex items-center justify-center text-white">
                        <i data-lucide="printer" class="w-6 h-6"></i>
                    </div>

                    <div>
                        <h1 class="font-bold text-lg text-slate-900">
                            PrintFlow Pro
                        </h1>

                        <p class="text-sm text-slate-500">
                            Order Management & CRM
                        </p>
                    </div>

                </div>

                <div class="flex items-center justify-between sm:justify-end gap-4">

                    <div class="text-left sm:text-right">
                        <p class="font-semibold text-sm">
                            <?= htmlspecialchars($admin_name) ?>
                        </p>

                        <p class="text-sm text-emerald-600">
                            Administrator
                        </p>
                    </div>

                    <a
                        href="dashboard.php?logout=1"
                        class="flex items-center gap-2 bg-slate-100 hover:bg-red-50 hover:text-red-600 px-4 py-3 rounded-xl text-sm font-semibold transition"
                        aria-label="Log out of PrintFlow"
                    >
                        <i data-lucide="log-out" class="w-5 h-5"></i>
                        Logout
                    </a>

                </div>

            </div>

            <!-- Consistent Admin Navigation -->
            <nav class="flex flex-wrap gap-2 mt-5" aria-label="Admin main navigation">

                <a
                    href="dashboard.php"
                    class="flex items-center gap-2 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 px-4 py-3 rounded-xl text-sm font-semibold transition"
                >
                    <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
                    Dashboard
                </a>

                <a
                    href="orders.php"
                    aria-current="page"
                    class="flex items-center gap-2 bg-indigo-600 text-white px-4 py-3 rounded-xl text-sm font-semibold"
                >
                    <i data-lucide="clipboard-list" class="w-5 h-5"></i>
                    Orders
                </a>

                <a
                    href="customers.php"
                    class="flex items-center gap-2 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 px-4 py-3 rounded-xl text-sm font-semibold transition"
                >
                    <i data-lucide="contact" class="w-5 h-5"></i>
                    Customers
                </a>

                <a
                    href="users.php"
                    class="flex items-center gap-2 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 px-4 py-3 rounded-xl text-sm font-semibold transition"
                >
                    <i data-lucide="users" class="w-5 h-5"></i>
                    Users
                </a>

                <a
                    href="reports.php"
                    class="flex items-center gap-2 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 px-4 py-3 rounded-xl text-sm font-semibold transition"
                >
                    <i data-lucide="chart-no-axes-combined" class="w-5 h-5"></i>
                    Reports
                </a>

            </nav>

        </div>

    </header>


    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 py-8">

        <!-- Page Heading -->
        <section class="mb-8">

            <h2 class="text-2xl font-bold text-slate-900">
                Order Management
            </h2>

            <p class="text-base text-slate-600 mt-2">
                View customer orders and monitor their progress.
            </p>

        </section>


        <!-- Notifications -->
        <?php if (isset($_GET["updated"])): ?>

            <div class="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl mb-6" role="status">
                Order status updated successfully.
            </div>

        <?php elseif (isset($_GET["error"])): ?>

            <div class="bg-red-50 border border-red-200 text-red-800 p-4 rounded-xl mb-6" role="alert">

                <?php
                $error = $_GET["error"];

                if ($error === "security") {
                    echo "Security verification failed. Please try again.";
                } elseif ($error === "invalid") {
                    echo "Invalid order information or status.";
                } elseif ($error === "quotation") {
                    echo "This order cannot be released because it has no accepted quotation.";
                } elseif ($error === "balance") {
                    echo "This order cannot be released yet. The customer must pay the full accepted quotation amount first.";
                } else {
                    echo "Unable to update the order. Please try again.";
                }
                ?>

            </div>

        <?php endif; ?>


        <!-- Order Count -->
        <section class="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm mb-6">

            <div class="flex items-center gap-4">

                <div class="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                    <i data-lucide="clipboard-list" class="w-6 h-6"></i>
                </div>

                <div>
                    <p class="text-sm text-slate-600">
                        Orders Found
                    </p>

                    <p class="text-2xl font-bold text-slate-900">
                        <?= number_format($total_displayed) ?>
                    </p>
                </div>

            </div>

        </section>


        <!-- Search -->
        <section class="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm mb-6">

            <form method="GET" action="orders.php" class="flex flex-col sm:flex-row gap-3">

                <div class="flex-1">

                    <label for="search" class="block text-sm font-semibold text-slate-700 mb-2">
                        Search Orders
                    </label>

                    <input
                        type="search"
                        id="search"
                        name="search"
                        value="<?= htmlspecialchars($search) ?>"
                        placeholder="Search by order ID, customer name, or status"
                        class="w-full border border-slate-300 rounded-xl px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >

                </div>

                <div class="flex items-end gap-2">

                    <button
                        type="submit"
                        class="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-3 rounded-xl font-semibold text-sm transition"
                    >
                        <i data-lucide="search" class="w-5 h-5"></i>
                        Search
                    </button>

                    <a
                        href="orders.php"
                        class="flex items-center justify-center bg-slate-100 hover:bg-slate-200 px-5 py-3 rounded-xl font-semibold text-sm transition"
                    >
                        Clear
                    </a>

                </div>

            </form>

        </section>


        <!-- Orders Table -->
        <section class="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">

            <div class="p-5 border-b border-slate-200">

                <h3 class="text-lg font-bold text-slate-900">
                    Customer Order Records
                </h3>

                <p class="text-sm text-slate-600 mt-1">
                    Review order information and update its current status.
                </p>

            </div>


            <?php if ($orders && $orders->num_rows > 0): ?>

                <div class="overflow-x-auto">

                    <table class="w-full text-left">

                        <thead class="bg-slate-50 border-b border-slate-200">

                            <tr class="text-sm text-slate-600">

                                <th scope="col" class="px-5 py-4">Order ID</th>
                                <th scope="col" class="px-5 py-4">Customer</th>
                                <th scope="col" class="px-5 py-4">Items</th>
                                <th scope="col" class="px-5 py-4">Order Date</th>
                                <th scope="col" class="px-5 py-4">Due Date</th>
                                <th scope="col" class="px-5 py-4">Total Amount</th>
                                <th scope="col" class="px-5 py-4">Order Status</th>
                                <th scope="col" class="px-5 py-4">Update</th>

                            </tr>

                        </thead>


                        <tbody class="divide-y divide-slate-100">

                            <?php while ($order = $orders->fetch_assoc()): ?>

                                <tr class="hover:bg-slate-50">

                                    <td class="px-5 py-4 font-bold text-indigo-700 whitespace-nowrap">
                                        #<?= (int)$order["order_id"] ?>
                                    </td>

                                    <td class="px-5 py-4 font-medium text-slate-800">
                                        <?= htmlspecialchars($order["full_name"]) ?>
                                    </td>

                                    <td class="px-5 py-4 text-slate-700">
                                        <?= (int)$order["item_count"] ?>
                                    </td>

                                    <td class="px-5 py-4 text-slate-600 whitespace-nowrap">
                                        <?= htmlspecialchars($order["order_date"]) ?>
                                    </td>

                                    <td class="px-5 py-4 text-slate-600 whitespace-nowrap">
                                        <?= htmlspecialchars($order["due_date"] ?? "Not set") ?>
                                    </td>

                                    <td class="px-5 py-4 font-semibold text-slate-800 whitespace-nowrap">
                                        ₱<?= number_format((float)$order["total_amount"], 2) ?>
                                    </td>

                                    <td class="px-5 py-4">

                                        <?php
                                        $status_class = "bg-slate-100 text-slate-700";

                                        if ($order["order_status"] === "Pending") {
                                            $status_class = "bg-amber-100 text-amber-800";
                                        } elseif ($order["order_status"] === "Design Approval") {
                                            $status_class = "bg-violet-100 text-violet-800";
                                        } elseif ($order["order_status"] === "In Production") {
                                            $status_class = "bg-blue-100 text-blue-800";
                                        } elseif ($order["order_status"] === "Completed" || $order["order_status"] === "Released") {
                                            $status_class = "bg-emerald-100 text-emerald-800";
                                        }
                                        ?>

                                        <span class="inline-block px-3 py-2 rounded-lg text-sm font-semibold whitespace-nowrap <?= $status_class ?>">
                                            <?= htmlspecialchars($order["order_status"]) ?>
                                        </span>

                                    </td>

                                    <td class="px-5 py-4">

                                        <form method="POST" action="orders.php" class="flex flex-col gap-2">

                                            <input
                                                type="hidden"
                                                name="order_id"
                                                value="<?= (int)$order["order_id"] ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="csrf_token"
                                                value="<?= htmlspecialchars($csrf_token) ?>"
                                            >

                                            <label
                                                for="status-<?= (int)$order["order_id"] ?>"
                                                class="sr-only"
                                            >
                                                Change status for order <?= (int)$order["order_id"] ?>
                                            </label>

                                            <select
                                                id="status-<?= (int)$order["order_id"] ?>"
                                                name="order_status"
                                                class="border border-slate-300 rounded-lg px-3 py-2 text-sm min-w-40 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                            >

                                                <?php foreach ($statuses as $status): ?>

                                                    <option
                                                        value="<?= htmlspecialchars($status) ?>"
                                                        <?= $order["order_status"] === $status ? "selected" : "" ?>
                                                    >
                                                        <?= htmlspecialchars($status) ?>
                                                    </option>

                                                <?php endforeach; ?>

                                            </select>

                                            <button
                                                type="submit"
                                                name="update_status"
                                                value="1"
                                                class="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-2 rounded-lg text-sm font-semibold transition"
                                            >
                                                Save Status
                                            </button>

                                        </form>

                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        </tbody>

                    </table>

                </div>

            <?php else: ?>

                <div class="text-center px-6 py-12">

                    <i data-lucide="search-x" class="w-12 h-12 text-slate-400 mx-auto"></i>

                    <h4 class="font-semibold text-lg text-slate-800 mt-4">
                        No orders found
                    </h4>

                    <p class="text-sm text-slate-600 mt-2">
                        Try another search or check back when new orders are placed.
                    </p>

                    <?php if (!empty($search)): ?>

                        <a
                            href="orders.php"
                            class="inline-block mt-4 text-indigo-700 hover:underline font-semibold"
                        >
                            Show all orders
                        </a>

                    <?php endif; ?>

                </div>

            <?php endif; ?>

        </section>

    </main>


    <footer class="text-center text-sm text-slate-500 py-6">
        PrintFlow Pro &copy; <?= date("Y") ?>. All rights reserved.
    </footer>


    <script>
        lucide.createIcons();
    </script>

</body>

</html>

<?php
$stmt->close();
$conn->close();
?>
