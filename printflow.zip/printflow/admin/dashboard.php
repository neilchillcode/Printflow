
<?php
session_start();

require_once "../config/database.php";

// Make sure the user is logged in
if (!isset($_SESSION["user_id"]) || !isset($_SESSION["user_role"])) {
    header("Location: ../login.php");
    exit;
}

// Only Admin accounts can access this page
if (strtolower($_SESSION["user_role"]) !== "admin") {
    header("Location: ../login.php");
    exit;
}

// Handle logout
if (isset($_GET["logout"])) {
    session_unset();
    session_destroy();

    header("Location: ../login.php");
    exit;
}

$admin_name = $_SESSION["user_name"] ?? "Administrator";

// Get total orders
$result = $conn->query("SELECT COUNT(*) AS total FROM orders");
$total_orders = $result->fetch_assoc()["total"];

// Get total customers
$result = $conn->query("SELECT COUNT(*) AS total FROM customers");
$total_customers = $result->fetch_assoc()["total"];

// Get pending orders
$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM orders
    WHERE order_status = 'Pending'
");
$pending_orders = $result->fetch_assoc()["total"];

// Get orders currently in production
$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM orders
    WHERE order_status = 'In Production'
");
$production_orders = $result->fetch_assoc()["total"];

// Get completed and released orders
$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM orders
    WHERE order_status IN ('Completed', 'Released')
");
$completed_orders = $result->fetch_assoc()["total"];

// Get total value of completed and released orders
$result = $conn->query("
    SELECT COALESCE(SUM(total_amount), 0) AS total
    FROM orders
    WHERE order_status IN ('Completed', 'Released')
");
$completed_value = $result->fetch_assoc()["total"];

// Get recent orders
$recent_orders = $conn->query("
    SELECT
        orders.order_id,
        customers.full_name,
        orders.order_date,
        orders.due_date,
        orders.order_status,
        orders.total_amount
    FROM orders
    INNER JOIN customers
        ON orders.customer_id = customers.customer_id
    ORDER BY orders.order_id DESC
    LIMIT 5
");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard | PrintFlow</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Inter', sans-serif;
        }

        a:focus {
            outline: 3px solid #818cf8;
            outline-offset: 3px;
        }
    </style>
</head>

<body class="bg-slate-100 text-slate-800 min-h-screen">

    <!-- Navigation -->
    <header class="bg-white border-b border-slate-200 shadow-sm">

        <div class="max-w-7xl mx-auto px-4 sm:px-6 py-4">

            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">

                <!-- Logo -->
                <div class="flex items-center gap-3">

                    <div class="w-11 h-11 bg-indigo-600 rounded-xl flex items-center justify-center text-white">
                        <i data-lucide="printer" class="w-6 h-6"></i>
                    </div>

                    <div>
                        <h1 class="font-bold text-lg text-slate-900">
                            PrintFlow Pro
                        </h1>

                        <p class="text-sm text-slate-500">
                            Order Management & CRM
                        </p>
                    </div>

                </div>

                <!-- Admin Information -->
                <div class="flex items-center justify-between sm:justify-end gap-4">

                    <div class="text-left sm:text-right">
                        <p class="font-semibold text-sm">
                            <?= htmlspecialchars($admin_name) ?>
                        </p>

                        <p class="text-sm text-emerald-600">
                            Administrator
                        </p>
                    </div>

                    <a
                        href="dashboard.php?logout=1"
                        class="flex items-center gap-2 bg-slate-100 hover:bg-red-50 hover:text-red-600 px-4 py-3 rounded-xl text-sm font-semibold transition"
                        aria-label="Log out of PrintFlow"
                    >
                        <i data-lucide="log-out" class="w-5 h-5"></i>
                        <span>Logout</span>
                    </a>

                </div>

            </div>

            <!-- Navigation Links -->
            <nav class="flex flex-wrap gap-2 mt-5" aria-label="Admin main navigation">

                <a
                    href="dashboard.php"
                    aria-current="page"
                    class="flex items-center gap-2 bg-indigo-600 text-white px-4 py-3 rounded-xl text-sm font-semibold"
                >
                    <i data-lucide="layout-dashboard" class="w-5 h-5"></i>
                    Dashboard
                </a>

                <a
                    href="orders.php"
                    class="flex items-center gap-2 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 px-4 py-3 rounded-xl text-sm font-semibold transition"
                >
                    <i data-lucide="clipboard-list" class="w-5 h-5"></i>
                    Orders
                </a>

                <a
                    href="customers.php"
                    class="flex items-center gap-2 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 px-4 py-3 rounded-xl text-sm font-semibold transition"
                >
                    <i data-lucide="contact" class="w-5 h-5"></i>
                    Customers
                </a>

                <a
                    href="users.php"
                    class="flex items-center gap-2 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 px-4 py-3 rounded-xl text-sm font-semibold transition"
                >
                    <i data-lucide="users" class="w-5 h-5"></i>
                    Users
                </a>

                <a
                    href="reports.php"
                    class="flex items-center gap-2 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 px-4 py-3 rounded-xl text-sm font-semibold transition"
                >
                    <i data-lucide="chart-no-axes-combined" class="w-5 h-5"></i>
                    Reports
                </a>

            </nav>

        </div>

    </header>


    <!-- Main Dashboard -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 py-8">

        <!-- Page Heading -->
        <section class="mb-8">

            <h2 class="text-2xl font-bold text-slate-900">
                Dashboard Overview
            </h2>

            <p class="text-base text-slate-600 mt-2">
                Welcome back! Here's an overview of your printing business.
            </p>

        </section>


        <!-- Summary Cards -->
        <section aria-label="Business statistics" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">

            <!-- Total Orders -->
            <div class="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">

                <div class="flex items-center justify-between">

                    <div>
                        <p class="text-sm font-medium text-slate-600">
                            Total Orders
                        </p>

                        <p class="text-3xl font-bold text-slate-900 mt-3">
                            <?= number_format($total_orders) ?>
                        </p>
                    </div>

                    <div class="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                        <i data-lucide="clipboard-list" class="w-7 h-7"></i>
                    </div>

                </div>

            </div>


            <!-- Total Customers -->
            <div class="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">

                <div class="flex items-center justify-between">

                    <div>
                        <p class="text-sm font-medium text-slate-600">
                            Total Customers
                        </p>

                        <p class="text-3xl font-bold text-slate-900 mt-3">
                            <?= number_format($total_customers) ?>
                        </p>
                    </div>

                    <div class="w-14 h-14 bg-violet-50 text-violet-600 rounded-xl flex items-center justify-center">
                        <i data-lucide="users" class="w-7 h-7"></i>
                    </div>

                </div>

            </div>


            <!-- Pending Orders -->
            <div class="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">

                <div class="flex items-center justify-between">

                    <div>
                        <p class="text-sm font-medium text-slate-600">
                            Pending Orders
                        </p>

                        <p class="text-3xl font-bold text-slate-900 mt-3">
                            <?= number_format($pending_orders) ?>
                        </p>
                    </div>

                    <div class="w-14 h-14 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center">
                        <i data-lucide="clock" class="w-7 h-7"></i>
                    </div>

                </div>

            </div>


            <!-- In Production -->
            <div class="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">

                <div class="flex items-center justify-between">

                    <div>
                        <p class="text-sm font-medium text-slate-600">
                            In Production
                        </p>

                        <p class="text-3xl font-bold text-slate-900 mt-3">
                            <?= number_format($production_orders) ?>
                        </p>
                    </div>

                    <div class="w-14 h-14 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
                        <i data-lucide="printer" class="w-7 h-7"></i>
                    </div>

                </div>

            </div>


            <!-- Completed Orders -->
            <div class="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">

                <div class="flex items-center justify-between">

                    <div>
                        <p class="text-sm font-medium text-slate-600">
                            Completed / Released
                        </p>

                        <p class="text-3xl font-bold text-slate-900 mt-3">
                            <?= number_format($completed_orders) ?>
                        </p>
                    </div>

                    <div class="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
                        <i data-lucide="check-circle" class="w-7 h-7"></i>
                    </div>

                </div>

            </div>


            <!-- Completed Order Value -->
            <div class="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">

                <div class="flex items-center justify-between">

                    <div>
                        <p class="text-sm font-medium text-slate-600">
                            Completed Order Value
                        </p>

                        <p class="text-3xl font-bold text-slate-900 mt-3">
                            ₱<?= number_format((float)$completed_value, 2) ?>
                        </p>
                    </div>

                    <div class="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
                        <i data-lucide="wallet" class="w-7 h-7"></i>
                    </div>

                </div>

            </div>

        </section>


        <!-- Recent Orders -->
        <section class="mt-10">

            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">

                <div>
                    <h3 class="text-xl font-bold text-slate-900">
                        Recent Orders
                    </h3>

                    <p class="text-sm text-slate-600 mt-1">
                        The latest orders recorded in PrintFlow.
                    </p>
                </div>

                <a
                    href="orders.php"
                    class="inline-flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-3 rounded-xl text-sm font-semibold transition"
                >
                    View All Orders
                    <i data-lucide="arrow-right" class="w-5 h-5"></i>
                </a>

            </div>


            <div class="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">

                <?php if ($recent_orders && $recent_orders->num_rows > 0): ?>

                    <div class="overflow-x-auto">

                        <table class="w-full text-left">

                            <thead class="bg-slate-50 border-b border-slate-200">

                                <tr class="text-sm text-slate-600">

                                    <th scope="col" class="px-5 py-4">Order ID</th>
                                    <th scope="col" class="px-5 py-4">Customer</th>
                                    <th scope="col" class="px-5 py-4">Order Date</th>
                                    <th scope="col" class="px-5 py-4">Due Date</th>
                                    <th scope="col" class="px-5 py-4">Amount</th>
                                    <th scope="col" class="px-5 py-4">Status</th>

                                </tr>

                            </thead>

                            <tbody class="divide-y divide-slate-100">

                                <?php while ($order = $recent_orders->fetch_assoc()): ?>

                                    <tr class="hover:bg-slate-50">

                                        <td class="px-5 py-4 font-semibold text-indigo-700">
                                            #<?= (int)$order["order_id"] ?>
                                        </td>

                                        <td class="px-5 py-4 font-medium text-slate-800">
                                            <?= htmlspecialchars($order["full_name"]) ?>
                                        </td>

                                        <td class="px-5 py-4 text-slate-600 whitespace-nowrap">
                                            <?= htmlspecialchars($order["order_date"]) ?>
                                        </td>

                                        <td class="px-5 py-4 text-slate-600 whitespace-nowrap">
                                            <?= htmlspecialchars($order["due_date"] ?? "Not set") ?>
                                        </td>

                                        <td class="px-5 py-4 font-semibold text-slate-800 whitespace-nowrap">
                                            ₱<?= number_format((float)$order["total_amount"], 2) ?>
                                        </td>

                                        <td class="px-5 py-4">

                                            <span class="inline-block px-3 py-2 rounded-lg text-sm font-semibold
                                                <?php
                                                if ($order["order_status"] === "Pending") {
                                                    echo "bg-amber-100 text-amber-800";
                                                } elseif ($order["order_status"] === "In Production") {
                                                    echo "bg-blue-100 text-blue-800";
                                                } elseif ($order["order_status"] === "Completed" || $order["order_status"] === "Released") {
                                                    echo "bg-emerald-100 text-emerald-800";
                                                } else {
                                                    echo "bg-slate-100 text-slate-700";
                                                }
                                                ?>
                                            ">
                                                <?= htmlspecialchars($order["order_status"]) ?>
                                            </span>

                                        </td>

                                    </tr>

                                <?php endwhile; ?>

                            </tbody>

                        </table>

                    </div>

                <?php else: ?>

                    <div class="text-center px-6 py-12">

                        <i data-lucide="clipboard-list" class="w-12 h-12 text-slate-400 mx-auto"></i>

                        <h4 class="font-semibold text-lg text-slate-800 mt-4">
                            No orders yet
                        </h4>

                        <p class="text-sm text-slate-600 mt-2">
                            New customer orders will appear here.
                        </p>

                    </div>

                <?php endif; ?>

            </div>

        </section>

    </main>


    <footer class="text-center text-sm text-slate-500 py-6">
        PrintFlow Pro &copy; <?= date("Y") ?>. All rights reserved.
    </footer>


    <script>
        lucide.createIcons();
    </script>

</body>
</html>

<?php
$conn->close();
?>
